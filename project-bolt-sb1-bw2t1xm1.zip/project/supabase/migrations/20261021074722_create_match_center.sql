/*
# Create Match Center storage

1. New Tables
- `matches` stores every scheduled or completed CIS League match as one validated JSON document.
- `matches.id` is the stable match identifier.
- `matches.status` identifies scheduled or completed matches.
- `matches.match_date` stores the match date/time for sorting and filtering.
- `matches.tournament` stores the tournament or round label.
- `matches.payload` stores format, teams, lineups, bench, ratings, events, and player-of-the-match details.
- `matches.created_at` and `matches.updated_at` track record changes.

2. Security
- Row level security is enabled on `matches`.
- This is a single shared league website without a sign-in screen, so anon and authenticated visitors may read, create, update, and delete match records.
- Separate policies are created for each CRUD operation.

3. Important notes
- Match details remain together in `payload` so the admin editor can evolve without losing existing protocols.
- The application validates the match shape before displaying or saving it.
*/

CREATE TABLE IF NOT EXISTS public.matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed')),
  match_date timestamptz NOT NULL,
  tournament text NOT NULL DEFAULT 'CIS League',
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can read matches" ON public.matches;
CREATE POLICY "Public can read matches" ON public.matches FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "Public can create matches" ON public.matches;
CREATE POLICY "Public can create matches" ON public.matches FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "Public can update matches" ON public.matches;
CREATE POLICY "Public can update matches" ON public.matches FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public can delete matches" ON public.matches;
CREATE POLICY "Public can delete matches" ON public.matches FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS matches_date_idx ON public.matches (match_date DESC);
CREATE INDEX IF NOT EXISTS matches_status_idx ON public.matches (status);
CREATE INDEX IF NOT EXISTS matches_tournament_idx ON public.matches (tournament);
