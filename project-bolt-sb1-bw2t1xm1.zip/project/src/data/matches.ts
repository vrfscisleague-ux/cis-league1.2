export type MatchFormat = '6x6' | '7x7' | '8x8' | '9x9' | '10x10';
export type MatchStatus = 'scheduled' | 'completed';
export type MatchEventType = 'goal' | 'card' | 'substitution';
export type MatchSideKey = 'home' | 'away';

export interface MatchTeam {
  name: string;
  logo: string;
}

export interface MatchPlayer {
  id: string;
  name: string;
  number?: number;
  position: string;
  x: number;
  y: number;
  rating: number;
}

export interface MatchSide {
  team: MatchTeam;
  score: number;
  lineup: MatchPlayer[];
  bench: MatchPlayer[];
}

export interface MatchEvent {
  id: string;
  type: MatchEventType;
  minute: number;
  side: MatchSideKey;
  player: string;
  assist?: string;
  card?: 'yellow' | 'red';
  playerIn?: string;
  playerOut?: string;
  penalty?: boolean;
  ownGoal?: boolean;
}

export interface MatchPayload {
  format: MatchFormat;
  formation?: string;
  home: MatchSide;
  away: MatchSide;
  events: MatchEvent[];
  motm?: string;
  notes?: string;
}

export interface MatchRecord {
  id: string;
  status: MatchStatus;
  match_date: string;
  tournament: string;
  payload: MatchPayload;
  created_at?: string;
  updated_at?: string;
}

export const matchFormats: MatchFormat[] = ['6x6', '7x7', '8x8', '9x9', '10x10'];

export const formationOptions: Record<MatchFormat, string[]> = {
  '6x6': ['1-2-2-1', '1-2-1-2', '1-3-1'],
  '7x7': ['1-2-3-1', '1-3-2-1', '1-3-1-2'],
  '8x8': ['1-3-2-2', '1-2-3-2', '1-3-3-1'],
  '9x9': ['1-3-3-2', '1-3-2-3', '1-4-2-2'],
  '10x10': ['1-4-3-2', '1-3-4-2', '1-4-2-3'],
};

export function emptyMatchPayload(format: MatchFormat = '6x6'): MatchPayload {
  return {
    format,
    formation: formationOptions[format][0],
    home: { team: { name: '', logo: '' }, score: 0, lineup: [], bench: [] },
    away: { team: { name: '', logo: '' }, score: 0, lineup: [], bench: [] },
    events: [],
    notes: '',
  };
}

export function isMatchPayload(value: unknown): value is MatchPayload {
  if (!value || typeof value !== 'object') return false;
  const payload = value as Partial<MatchPayload>;
  return matchFormats.includes(payload.format as MatchFormat)
    && Boolean(payload.home?.team?.name)
    && Boolean(payload.away?.team?.name)
    && Array.isArray(payload.home?.lineup)
    && Array.isArray(payload.away?.lineup)
    && Array.isArray(payload.events);
}

export function formatMatchDate(value: string) {
  return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
}

export const matchPositions = ['ГК', 'ПЗ', 'ЦЗ', 'ЛЗ', 'ЦОП', 'ЦП', 'ЦАП', 'ЛВ', 'ФРВ', 'ПВ'] as const;
export type MatchPosition = (typeof matchPositions)[number];

const homePositionCoords: Record<MatchPosition, { x: number; y: number }> = {
  ГК: { x: 8, y: 50 },
  ПЗ: { x: 22, y: 22 },
  ЦЗ: { x: 22, y: 50 },
  ЛЗ: { x: 22, y: 78 },
  ЦОП: { x: 38, y: 50 },
  ЦП: { x: 50, y: 35 },
  ЦАП: { x: 58, y: 65 },
  ЛВ: { x: 70, y: 78 },
  ФРВ: { x: 78, y: 50 },
  ПВ: { x: 70, y: 22 },
};

export const positionLabelsFull: Record<MatchPosition, string> = {
  ГК: 'Вратарь',
  ПЗ: 'Правый защитник',
  ЦЗ: 'Центральный защитник',
  ЛЗ: 'Левый защитник',
  ЦОП: 'Опорный полузащитник',
  ЦП: 'Центральный полузащитник',
  ЦАП: 'Атакующий полузащитник',
  ЛВ: 'Левый вингер',
  ФРВ: 'Форвард',
  ПВ: 'Правый вингер',
};

export function positionCoordinate(position: string, side: MatchSideKey): { x: number; y: number } {
  const home = homePositionCoords[position as MatchPosition];
  if (!home) return { x: side === 'home' ? 50 : 50, y: 50 };
  return { x: side === 'home' ? home.x : 100 - home.x, y: home.y };
}

export function lineupCoordinates(format: MatchFormat, side: MatchSideKey, formation?: string): { x: number; y: number }[] {
  const count = Number(format.split('x')[0]);
  const goalkeeper = { x: side === 'home' ? 8 : 92, y: 50 };
  const rows = (formation ?? formationOptions[format][0]).split('-').slice(1).map(Number).filter(Boolean);
  const positions: { x: number; y: number }[] = [goalkeeper];
  rows.forEach((rowCount, rowIndex) => {
    for (let i = 0; i < rowCount; i += 1) {
      const depth = 22 + rowIndex * (58 / Math.max(rows.length - 1, 1));
      const y = ((i + 1) / (rowCount + 1)) * 88 + 6;
      positions.push({ x: side === 'home' ? depth : 100 - depth, y });
    }
  });
  return positions.slice(0, count);
}

export function getMatchStats(matches: MatchRecord[]) {
  const stats = new Map<string, { goals: number; assists: number; matches: number }>();
  matches.forEach((match) => {
    const names = [...match.payload.home.lineup, ...match.payload.home.bench, ...match.payload.away.lineup, ...match.payload.away.bench];
    names.forEach((player) => {
      if (!stats.has(player.name)) stats.set(player.name, { goals: 0, assists: 0, matches: match.status === 'completed' ? 1 : 0 });
    });
    match.payload.events.forEach((event) => {
      if (event.type !== 'goal') return;
      const scorer = stats.get(event.player);
      if (scorer) scorer.goals += 1;
      if (event.assist) {
        const assister = stats.get(event.assist);
        if (assister) assister.assists += 1;
      }
    });
  });
  return stats;
}
