import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { legends as defaultLegends, clubs, directoryPlayers, type DirectoryPlayer, type Legend } from '@/data/mockData';
import { supabase } from '@/lib/supabase';
import type { MatchRecord } from '@/data/matches';

export interface LegendOverride {
  currentClubId?: string | null;
  clubRole?: string;
  goals?: number;
  assists?: number;
  matches?: number;
  strengths?: string[];
  biography?: string;
  achievements?: string[];
}

export type EditableLegend = Legend & LegendOverride;

const STORAGE_KEY = 'cis-league-overrides';
const PLAYERS_STORAGE_KEY = 'cis-league-directory-players-v2';

type Overrides = Record<string, LegendOverride>;

interface DataContextValue {
  legends: EditableLegend[];
  players: DirectoryPlayer[];
  clubs: typeof clubs;
  updateLegend: (id: number, override: Partial<LegendOverride>) => void;
  resetLegend: (id: number) => void;
  getOverride: (id: number) => LegendOverride | undefined;
  addPlayer: (player: Omit<DirectoryPlayer, 'id'>) => void;
  updatePlayer: (id: number, patch: Partial<Omit<DirectoryPlayer, 'id'>>) => void;
  deletePlayer: (id: number) => void;
  matches: MatchRecord[];
  matchesLoading: boolean;
  matchesError: string | null;
  addMatch: (match: Omit<MatchRecord, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateMatch: (id: string, match: Omit<MatchRecord, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  deleteMatch: (id: string) => Promise<void>;
}

const DataContext = createContext<DataContextValue | null>(null);

function loadOverrides(): Overrides {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as Overrides;
  } catch {
    // ignore
  }
  return {};
}

function saveOverrides(overrides: Overrides) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(overrides));
  } catch {
    // ignore
  }
}

function loadPlayers(): DirectoryPlayer[] {
  try {
    const raw = localStorage.getItem(PLAYERS_STORAGE_KEY);
    if (raw) return JSON.parse(raw) as DirectoryPlayer[];
  } catch {
    // ignore
  }
  return directoryPlayers;
}

function savePlayers(players: DirectoryPlayer[]) {
  try {
    localStorage.setItem(PLAYERS_STORAGE_KEY, JSON.stringify(players));
  } catch {
    // ignore
  }
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [overrides, setOverrides] = useState<Overrides>({});
  const [players, setPlayers] = useState<DirectoryPlayer[]>(directoryPlayers);
  const [matches, setMatches] = useState<MatchRecord[]>([]);
  const [matchesLoading, setMatchesLoading] = useState(true);
  const [matchesError, setMatchesError] = useState<string | null>(null);

  useEffect(() => {
    setOverrides(loadOverrides());
    setPlayers(loadPlayers());
    void loadMatches();
  }, []);

  const loadMatches = async () => {
    setMatchesLoading(true);
    const { data, error } = await supabase.from('matches').select('*').order('match_date', { ascending: false });
    if (error) setMatchesError('Матчи пока недоступны. Попробуйте обновить страницу.');
    else setMatches((data ?? []) as MatchRecord[]);
    setMatchesLoading(false);
  };

  const updateOverride = (id: number, patch: Partial<LegendOverride>) => {
    setOverrides((prev) => {
      const key = String(id);
      const next = { ...prev, [key]: { ...prev[key], ...patch } };
      saveOverrides(next);
      return next;
    });
  };

  const resetLegend = (id: number) => {
    setOverrides((prev) => {
      const next = { ...prev };
      delete next[String(id)];
      saveOverrides(next);
      return next;
    });
  };

  const mergedLegends: EditableLegend[] = defaultLegends.map((l) => {
    const ov = overrides[String(l.id)];
    if (!ov) return l;
    return {
      ...l,
      strengths: ov.strengths ?? l.strengths,
      achievements: ov.achievements ?? l.achievements,
      description: ov.biography ?? l.description,
      currentClubId: ov.currentClubId ?? null,
      clubRole: ov.clubRole,
      goals: ov.goals,
      assists: ov.assists,
      matches: ov.matches,
    };
  });

  const getOverride = (id: number) => overrides[String(id)];

  const addPlayer = (player: Omit<DirectoryPlayer, 'id'>) => {
    setPlayers((prev) => {
      const next = [...prev, { ...player, id: Date.now() }];
      savePlayers(next);
      return next;
    });
  };

  const updatePlayer = (id: number, patch: Partial<Omit<DirectoryPlayer, 'id'>>) => {
    setPlayers((prev) => {
      const next = prev.map((player) => player.id === id ? { ...player, ...patch } : player);
      savePlayers(next);
      return next;
    });
  };

  const deletePlayer = (id: number) => {
    setPlayers((prev) => {
      const next = prev.filter((player) => player.id !== id);
      savePlayers(next);
      return next;
    });
  };

  const addMatch = async (match: Omit<MatchRecord, 'id' | 'created_at' | 'updated_at'>) => {
    const { data, error } = await supabase.from('matches').insert({ status: match.status, match_date: match.match_date, tournament: match.tournament, payload: match.payload }).select().maybeSingle();
    if (error || !data) throw new Error('Не удалось сохранить матч');
    setMatches((prev) => [data as MatchRecord, ...prev]);
  };

  const updateMatch = async (id: string, match: Omit<MatchRecord, 'id' | 'created_at' | 'updated_at'>) => {
    const { data, error } = await supabase.from('matches').update({ status: match.status, match_date: match.match_date, tournament: match.tournament, payload: match.payload, updated_at: new Date().toISOString() }).eq('id', id).select().maybeSingle();
    if (error || !data) throw new Error('Не удалось обновить матч');
    setMatches((prev) => prev.map((item) => item.id === id ? data as MatchRecord : item));
  };

  const deleteMatch = async (id: string) => {
    const { error } = await supabase.from('matches').delete().eq('id', id);
    if (error) throw new Error('Не удалось удалить матч');
    setMatches((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <DataContext.Provider
      value={{
        legends: mergedLegends,
        players,
        clubs,
        updateLegend: updateOverride,
        resetLegend,
        getOverride,
        addPlayer,
        updatePlayer,
        deletePlayer,
        matches,
        matchesLoading,
        matchesError,
        addMatch,
        updateMatch,
        deleteMatch,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
