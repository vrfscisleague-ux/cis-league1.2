import { useState, useEffect } from 'react';
import Header, { type TabKey } from '@/components/Header';
import ClubDetailView from '@/components/ClubDetailView';
import { clubs } from '@/data/mockData';
import Home from '@/components/Home';
import HallOfFame from '@/components/HallOfFame';
import Legends from '@/components/Legends';
import Seasons from '@/components/Seasons';
import Clubs from '@/components/Clubs';
import About from '@/components/About';
import Players from '@/components/Players';
import MatchCenter from '@/components/MatchCenter';
import Admin from '@/components/Admin';
import { DataProvider } from '@/context/DataContext';

function App() {
  const [tab, setTab] = useState<TabKey>('home');
  const [selectedClubId, setSelectedClubId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkAdminRoute = () => {
      const path = window.location.pathname.replace(/\/$/, '');
      const hash = window.location.hash.toLowerCase();
      const query = new URLSearchParams(window.location.search);
      setIsAdmin(path.endsWith('/admin') || hash === '#admin' || hash === '#/admin' || query.has('admin'));
    };
    checkAdminRoute();
    window.addEventListener('hashchange', checkAdminRoute);
    window.addEventListener('popstate', checkAdminRoute);
    return () => {
      window.removeEventListener('hashchange', checkAdminRoute);
      window.removeEventListener('popstate', checkAdminRoute);
    };
  }, []);

  const selectedClub = clubs.find((club) => club.id === selectedClubId);

  const handleTabChange = (nextTab: TabKey) => {
    setTab(nextTab);
    setSelectedClubId(null);
  };

  return (
    <DataProvider>
      <div className="min-h-screen bg-black text-white">
        {isAdmin ? (
          <main className="mx-auto max-w-4xl px-4 py-8 md:px-6 md:py-12">
            <Admin />
          </main>
        ) : (
          <>
            <Header active={tab} onTab={handleTabChange} />
            <main className="mx-auto max-w-7xl px-4 py-8 md:px-6 md:py-12">
              {tab === 'home' && <Home onTab={setTab} />}
              {tab === 'hall' && (
                <>
                  <Seasons />
                  <div className="mt-12">
                    <HallOfFame />
                  </div>
                </>
              )}
              {tab === 'legends' && <Legends />}
              {tab === 'players' && <Players />}
              {tab === 'matches' && <MatchCenter />}
              {tab === 'clubs' &&
                (selectedClub ? (
                  <ClubDetailView club={selectedClub} onBack={() => setSelectedClubId(null)} />
                ) : (
                  <Clubs onSelectClub={setSelectedClubId} />
                ))}
              {tab === 'about' && <About />}
            </main>
          </>
        )}
        <footer className="border-t border-rose-950/40 py-8 text-center text-xs text-zinc-600">
          <p>CIS LEAGUE · VRFS Esports · 2023—2026</p>
          <p className="mt-1 text-zinc-700">Премиальный киберспортивный чемпионат СНГ</p>
        </footer>
      </div>
    </DataProvider>
  );
}

export default App;
