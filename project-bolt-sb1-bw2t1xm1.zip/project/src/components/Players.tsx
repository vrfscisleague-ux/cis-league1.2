import { useMemo, useState } from 'react';
import { Search, SlidersHorizontal, UserRound, X, Target, Hand, Calendar, Ruler, Sparkles, Crown } from 'lucide-react';
import { useData, type EditableLegend } from '@/context/DataContext';
import type { DirectoryPlayer } from '@/data/mockData';
import { getMatchStats } from '@/data/matches';
import PlayerProfile from '@/components/PlayerProfile';

const positions = ['Все позиции', 'GK', 'DEF', 'MID', 'FWD'];

export default function Players() {
  const { players, clubs: clubList, legends, matches } = useData();
  const protocolStats = getMatchStats(matches);
  const [query, setQuery] = useState('');
  const [club, setClub] = useState('Все клубы');
  const [position, setPosition] = useState('Все позиции');
  const [selectedPlayer, setSelectedPlayer] = useState<DirectoryPlayer | null>(null);
  const [selectedLegend, setSelectedLegend] = useState<EditableLegend | null>(null);
  const openPlayer = (player: DirectoryPlayer) => {
    const legend = legends.find((l) => l.nickname.toLowerCase() === player.name.toLowerCase());
    if (legend) setSelectedLegend(legend); else setSelectedPlayer(player);
  };
  const clubNames = [...new Set(players.map((player) => player.currentClub))].sort();
  const legendNames = new Set(legends.map((l) => l.nickname.toLowerCase()));
  const filtered = useMemo(() => players.filter((player) =>
    player.name.toLowerCase().includes(query.toLowerCase()) &&
    (club === 'Все клубы' || player.currentClub === club) &&
    (position === 'Все позиции' || player.position === position)
  ), [players, query, club, position]);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-700 to-rose-950 ring-1 ring-rose-500/40"><UserRound className="h-7 w-7 text-white" /></div>
        <h2 className="text-3xl font-extrabold text-white md:text-4xl">Все игроки</h2>
        <p className="mt-2 text-zinc-500">Players Directory · {players.length} игроков в базе CIS League</p>
      </div>
      <div className="grid gap-3 rounded-2xl border border-zinc-800 bg-zinc-950/60 p-4 md:grid-cols-[1fr_200px_180px]">
        <label className="relative"><Search className="absolute left-3 top-3 h-4 w-4 text-zinc-500" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск по нику" className="w-full rounded-lg border border-zinc-700 bg-black/60 py-2.5 pl-10 pr-3 text-white outline-none focus:border-rose-600" /></label>
        <select value={club} onChange={(e) => setClub(e.target.value)} className="rounded-lg border border-zinc-700 bg-black/60 px-3 py-2.5 text-white outline-none focus:border-rose-600"><option>Все клубы</option>{clubNames.map((name) => <option key={name}>{name}</option>)}</select>
        <select value={position} onChange={(e) => setPosition(e.target.value)} className="rounded-lg border border-zinc-700 bg-black/60 px-3 py-2.5 text-white outline-none focus:border-rose-600">{positions.map((item) => <option key={item}>{item}</option>)}</select>
      </div>
      <p className="flex items-center gap-2 text-sm text-zinc-500"><SlidersHorizontal className="h-4 w-4 text-rose-500" /> Показано игроков: <span className="font-bold text-white">{filtered.length}</span></p>
      <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-950/60">
        <div className="hidden grid-cols-[2fr_1fr_1fr_1fr_1fr] gap-4 border-b border-zinc-800 px-5 py-3 text-xs font-bold uppercase tracking-wider text-zinc-500 md:grid"><span>Игрок</span><span>Позиция</span><span>Клуб</span><span>Статистика</span><span>Скиллы</span></div>
        {filtered.map((player) => { const clubInfo = clubList.find((c) => c.name === player.currentClub); const isLegend = legendNames.has(player.name.toLowerCase()); const protocol = protocolStats.get(player.name); const totalGoals = player.goals + (protocol?.goals ?? 0); const totalAssists = player.assists + (protocol?.assists ?? 0); const totalMatches = player.matches + (protocol?.matches ?? 0); return <button key={player.id} onClick={() => openPlayer(player)} className="grid w-full gap-3 border-b border-zinc-800 px-4 py-4 text-left transition last:border-b-0 hover:bg-rose-950/20 md:grid-cols-[2fr_1fr_1fr_1fr_1fr] md:items-center md:gap-4 md:px-5"><span className="flex items-center gap-3"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-rose-700 to-rose-950 text-sm font-extrabold text-white">{player.name.slice(0, 2).toUpperCase()}</span><span><strong className="flex items-center gap-1.5 text-white">{player.name}{isLegend && <Crown className="h-3.5 w-3.5 text-amber-400" />}</strong><small className="text-zinc-500">{player.age} лет · {player.height}</small></span></span><span className="text-sm font-semibold text-rose-300">{player.position}</span><span className="flex items-center gap-2 truncate text-sm text-zinc-300">{clubInfo ? <img src={clubInfo.logo} alt={clubInfo.name} className="h-5 w-5 shrink-0 rounded object-contain" /> : null}<span className="truncate">{player.currentClub}</span></span><span className="text-sm text-zinc-400">{totalGoals} гол. · {totalAssists} асс. · {totalMatches} матч.</span><span className="flex flex-wrap gap-1.5">{player.skills.slice(0, 2).map((skill) => <span key={skill} className="rounded-md border border-zinc-800 bg-zinc-900/60 px-2 py-1 text-[11px] text-zinc-300">{skill}</span>)}</span></button>; })}
      </div>
      {filtered.length === 0 && <div className="rounded-2xl border border-dashed border-zinc-700 p-12 text-center text-zinc-500">Игроки по заданным фильтрам не найдены.</div>}
      {selectedPlayer && <PlayerModal player={selectedPlayer} onClose={() => setSelectedPlayer(null)} />}
      {selectedLegend && <PlayerProfile legend={selectedLegend} onClose={() => setSelectedLegend(null)} />}
    </div>
  );
}

function PlayerModal({ player, onClose }: { player: DirectoryPlayer; onClose: () => void }) {
  const { clubs: clubList, matches } = useData();
  const clubInfo = clubList.find((c) => c.name === player.currentClub);
  const protocol = getMatchStats(matches).get(player.name);
  const totalGoals = player.goals + (protocol?.goals ?? 0);
  const totalAssists = player.assists + (protocol?.assists ?? 0);
  const totalMatches = player.matches + (protocol?.matches ?? 0);
  return <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 p-4 backdrop-blur-sm" onClick={onClose}><div className="mx-auto my-8 max-w-2xl rounded-2xl border border-rose-900/50 bg-gradient-to-b from-zinc-950 to-black p-6 shadow-2xl md:p-8" onClick={(e) => e.stopPropagation()}>
    <div className="flex items-start justify-between"><div className="flex items-center gap-4"><div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-700 to-rose-950 text-xl font-extrabold text-white">{player.name.slice(0, 2).toUpperCase()}</div><div><h2 className="text-2xl font-extrabold text-white">{player.name}</h2><p className="flex items-center gap-1.5 text-rose-400">{player.position} · {clubInfo ? <><img src={clubInfo.logo} alt={clubInfo.name} className="h-4 w-4 rounded object-contain" /> {player.currentClub}</> : player.currentClub}</p></div></div><button onClick={onClose} className="rounded-lg p-2 text-zinc-500 hover:bg-zinc-900 hover:text-white"><X /></button></div>
    <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4"><Info icon={<UserRound />} label="Возраст" value={`${player.age} лет`} /><Info icon={<Ruler />} label="Рост" value={player.height} /><Info icon={<Target />} label="Голы" value={String(totalGoals)} /><Info icon={<Hand />} label="Ассисты" value={String(totalAssists)} /></div>
    <div className="mt-7"><h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500"><Sparkles className="h-4 w-4 text-rose-500" /> Качества и скиллы</h3><div className="mt-3 flex flex-wrap gap-2">{player.skills.map((skill) => <span key={skill} className="rounded-lg border border-rose-900/50 bg-rose-950/30 px-3 py-2 text-sm font-semibold text-rose-200">{skill}</span>)}</div></div>
    <div className="mt-7 rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 text-sm text-zinc-400"><Calendar className="mr-2 inline h-4 w-4 text-rose-500" /> Матчи: <strong className="text-white">{totalMatches}</strong></div>
  </div></div>;
}

function Info({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) { return <div className="rounded-xl border border-zinc-800 bg-zinc-950/70 p-3"><div className="flex items-center gap-1.5 text-xs text-zinc-500">{icon} {label}</div><p className="mt-2 font-extrabold text-white">{value}</p></div>; }
