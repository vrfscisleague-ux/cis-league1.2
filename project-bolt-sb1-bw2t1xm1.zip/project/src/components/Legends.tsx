import { useState } from 'react';
import { Crown, Star, Award, Zap, Target, Pencil, Trophy, Goal, Hand, ArrowRight, Shield } from 'lucide-react';
import { seasonAwards, topScorersS1, topScorersS2, ballonDorS1 } from '@/data/mockData';
import PlayerProfile from '@/components/PlayerProfile';
import { useData, type EditableLegend } from '@/context/DataContext';

const PLACEHOLDER = 'Заполнить позже';

function isPlaceholder(value: string) {
  return value === PLACEHOLDER;
}

const awardIconLabel: Record<string, string> = {
  ballondor: 'Ballon d\'Or',
  boot: 'Golden Boot',
  playmaker: 'Playmaker',
  defender: 'Best Defender',
  glove: 'Golden Glove',
  boy: 'Golden Boy',
  manager: 'Best Manager',
};

function aggregateRiNOStats() {
  let goals = 0;
  let assists = 0;
  let awards = 0;

  topScorersS1.forEach((s) => {
    if (s.nickname === 'RiNO') goals += s.goals;
  });
  topScorersS2.forEach((s) => {
    if (s.nickname === 'RiNO') goals += s.goals;
  });
  ballonDorS1.forEach((b) => {
    if (b.nickname === 'RINO PAPA' || b.nickname === 'RiNO') {
      goals += b.goals;
      assists += b.assists;
    }
  });

  seasonAwards.forEach((season) => {
    season.awards.forEach((award) => {
      if (award.winner === 'RiNO') awards += 1;
    });
  });

  return { goals, assists, awards };
}

export default function Legends() {
  const { legends, clubs } = useData();
  const [selected, setSelected] = useState<EditableLegend | null>(null);
  const rinoStats = aggregateRiNOStats();
  const rinoAwards = seasonAwards
    .flatMap((season) =>
      season.awards
        .filter((a) => a.winner === 'RiNO')
        .map((a) => ({
          title: a.title,
          season: season.season,
          year: season.year,
          icon: a.icon,
          description: a.description,
        }))
    );

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-700 to-rose-950 ring-1 ring-rose-500/40">
          <Crown className="h-7 w-7 text-white" />
        </div>
        <h2 className="text-3xl font-extrabold text-white md:text-4xl">Почетные игроки СНГ</h2>
        <p className="mt-2 text-zinc-500">
          Легенды и ключевые игроки сообщества, чьи перформансы вошли в историю VRFS-лиги
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {legends.map((l) => {
          const draft = l.draft ?? false;
          const isRiNO = l.nickname === 'RiNO';
          const stats = isRiNO ? rinoStats : null;
          const awards = isRiNO ? rinoAwards : [];
          const clubId = l.currentClubId ?? (isRiNO ? 'latvia' : null);
          const currentClub = clubId ? clubs.find((c) => c.id === clubId) : null;
          const clubRoleText = l.clubRole ?? 'Игрок';
          return (
            <article
              key={l.id}
              onClick={() => setSelected(l)}
              className={`group relative flex cursor-pointer flex-col overflow-hidden rounded-2xl border p-6 transition ${
                draft
                  ? 'border-dashed border-rose-700/50 bg-gradient-to-br from-rose-950/20 to-black hover:border-rose-600/80'
                  : 'border-zinc-800 bg-gradient-to-br from-zinc-950 to-black hover:border-rose-700/70'
              } hover:shadow-xl hover:shadow-rose-950/30`}
            >
              <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-rose-800/10 blur-3xl transition group-hover:bg-rose-700/20" />

              {draft && (
                <span className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-md border border-rose-700/40 bg-rose-950/60 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-300">
                  <Pencil className="h-3 w-3" /> Шаблон
                </span>
              )}

              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-rose-700 to-rose-950 text-base font-extrabold text-white ring-1 ring-rose-500/40">
                    {l.nickname.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <h3 className="truncate text-lg font-extrabold text-white">{l.nickname}</h3>
                    <p className={`truncate text-xs ${isPlaceholder(l.role) ? 'italic text-zinc-600' : 'text-rose-400'}`}>
                      {l.role}
                    </p>
                  </div>
                </div>
              </div>

              <span className="mt-4 inline-flex w-fit items-center gap-1.5 rounded-md bg-rose-950/60 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-rose-300 ring-1 ring-rose-700/40">
                <Star className="h-3 w-3" /> {l.badge}
              </span>

              {/* Current Club */}
              {currentClub && (
                <div className="mt-4 flex items-center gap-3 rounded-xl border border-rose-900/40 bg-rose-950/20 p-3">
                  <img
                    src={currentClub.logo}
                    alt={currentClub.name}
                    className="h-10 w-10 rounded-lg object-cover ring-1 ring-zinc-700"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-rose-400">
                      <Shield className="h-3 w-3" /> Текущий клуб
                    </p>
                    <p className="truncate text-sm font-bold text-white">{currentClub.name}</p>
                    <p className="truncate text-xs text-zinc-400">{clubRoleText}</p>
                  </div>
                  {currentClub.status === 'active' && (
                    <span className="rounded bg-emerald-950/60 px-1.5 py-0.5 text-[10px] font-bold uppercase text-emerald-400 ring-1 ring-emerald-700/40">
                      Активен
                    </span>
                  )}
                </div>
              )}

              <p
                className={`mt-4 text-sm leading-relaxed ${
                  isPlaceholder(l.description) ? 'italic text-zinc-600' : 'text-zinc-400'
                }`}
              >
                {l.description}
              </p>

              {/* Stats */}
              {stats && (
                <div className="mt-5 grid grid-cols-3 gap-2">
                  <div className="rounded-xl border border-rose-900/40 bg-rose-950/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-wider text-rose-400">
                      <Goal className="h-3 w-3" /> Голы
                    </div>
                    <div className="mt-1 text-2xl font-extrabold text-white">{stats.goals}</div>
                  </div>
                  <div className="rounded-xl border border-rose-900/40 bg-rose-950/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-wider text-rose-400">
                      <Hand className="h-3 w-3" /> Ассисты
                    </div>
                    <div className="mt-1 text-2xl font-extrabold text-white">{stats.assists}</div>
                  </div>
                  <div className="rounded-xl border border-rose-900/40 bg-rose-950/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-wider text-rose-400">
                      <Trophy className="h-3 w-3" /> Награды
                    </div>
                    <div className="mt-1 text-2xl font-extrabold text-white">{stats.awards}</div>
                  </div>
                </div>
              )}

              {/* Individual Awards */}
              {awards.length > 0 && (
                <div className="mt-5">
                  <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">
                    <Trophy className="h-3.5 w-3.5 text-rose-500" /> Индивидуальные награды
                  </p>
                  <div className="mt-2 space-y-1.5">
                    {awards.map((a, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 rounded-md border border-amber-800/40 bg-amber-950/30 px-2.5 py-1.5 text-xs"
                      >
                        <Trophy className="h-3.5 w-3.5 shrink-0 text-amber-400" />
                        <span className="font-bold text-amber-200">{awardIconLabel[a.icon ?? ''] ?? a.title}</span>
                        <span className="ml-auto shrink-0 text-amber-300/70">{a.season} · {a.year}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strengths */}
              <div className="mt-5">
                <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">
                  <Zap className="h-3.5 w-3.5 text-rose-500" /> Лучшие качества
                </p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {l.strengths.map((s) => (
                    <span
                      key={s}
                      className={`rounded-md border px-2 py-1 text-xs font-semibold transition ${
                        isPlaceholder(s)
                          ? 'border-dashed border-zinc-700 bg-zinc-900/40 text-zinc-600'
                          : 'border-zinc-800 bg-zinc-900/60 text-zinc-300 hover:border-rose-700/50 hover:text-white'
                      }`}
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Achievements */}
              <div className="mt-5">
                <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">
                  <Award className="h-3.5 w-3.5 text-rose-500" /> Достижения в СНГ и вне
                </p>
                <ul className="mt-2 space-y-1.5">
                  {l.achievements.map((a, i) => (
                    <li
                      key={i}
                      className={`flex gap-2 text-xs ${
                        isPlaceholder(a) ? 'italic text-zinc-600' : 'text-zinc-400'
                      }`}
                    >
                      <Target className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-500" />
                      <span className="leading-relaxed">{a}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                tabIndex={-1}
                className="mt-5 flex items-center justify-center gap-1.5 rounded-lg border border-zinc-800 bg-zinc-900/40 py-2 text-xs font-bold text-zinc-400 transition group-hover:border-rose-700/50 group-hover:text-rose-300"
              >
                Подробнее / Профиль <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </article>
          );
        })}
      </div>

      {selected && <PlayerProfile legend={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
