import { useState, useEffect } from 'react';
import { Lock, LogOut, Shield, Save, RotateCcw, User, Plus, X, Target, Hand, Calendar, Zap, Award, Trash2, Pencil, UsersRound, ArrowLeft } from 'lucide-react';
import { useData } from '@/context/DataContext';
import type { DirectoryPlayer } from '@/data/mockData';
import { emptyMatchPayload, formationOptions, matchFormats, matchPositions, positionCoordinate, positionLabelsFull, type MatchEvent, type MatchFormat, type MatchPayload, type MatchPlayer, type MatchRecord, type MatchSideKey } from '@/data/matches';

const ADMIN_PASSWORD = 'R!n0_2026#CIS_League!';
const AUTH_KEY = 'cis-league-admin-auth';

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  useEffect(() => {
    if (localStorage.getItem(AUTH_KEY) === 'true') setAuthed(true);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      localStorage.setItem(AUTH_KEY, 'true');
      setAuthed(true);
      setError(false);
    } else {
      setError(true);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(AUTH_KEY);
    setAuthed(false);
    setPassword('');
  };

  const handleExit = () => {
    const publicUrl = new URL(window.location.href);
    publicUrl.pathname = publicUrl.pathname.replace(/\/admin\/?$/, '/') || '/';
    publicUrl.searchParams.delete('admin');
    publicUrl.hash = 'home';
    window.location.assign(publicUrl.toString());
  };

  if (!authed) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center">
        <div className="w-full max-w-md">
          <button
            type="button"
            onClick={handleExit}
            className="mb-4 inline-flex items-center gap-2 rounded-lg border border-zinc-800 px-4 py-2.5 text-sm font-semibold text-zinc-400 transition hover:border-rose-700 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" /> На сайт
          </button>
          <form
            onSubmit={handleLogin}
            className="rounded-2xl border border-rose-900/50 bg-gradient-to-br from-zinc-950 to-black p-8 shadow-2xl"
          >
            <div className="mb-6 flex flex-col items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-rose-700 to-rose-950 ring-1 ring-rose-500/40">
                <Lock className="h-7 w-7 text-white" />
              </div>
              <h2 className="text-2xl font-extrabold text-white">Админ-панель</h2>
              <p className="text-sm text-zinc-500">Введите пароль для доступа к управлению</p>
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError(false);
              }}
              placeholder="Пароль"
              className={`w-full rounded-lg border bg-black/60 px-4 py-3 text-white placeholder-zinc-600 outline-none transition focus:ring-2 ${
                error ? 'border-red-600 focus:ring-red-600/30' : 'border-zinc-700 focus:border-rose-600 focus:ring-rose-600/30'
              }`}
              autoFocus
            />
            {error && <p className="mt-2 text-sm font-semibold text-red-400">Неверный пароль</p>}
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <button
                type="submit"
                className="w-full rounded-lg bg-gradient-to-br from-rose-600 to-rose-900 px-5 py-3 font-bold text-white ring-1 ring-rose-500/50 transition hover:from-rose-500 hover:to-rose-800"
              >
                Войти
              </button>
              <button
                type="button"
                onClick={handleExit}
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-zinc-700 px-5 py-3 font-bold text-zinc-300 transition hover:border-rose-600 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4" /> На сайт
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return <AdminDashboard onLogout={handleLogout} onExit={handleExit} />;
}

function AdminDashboard({ onLogout, onExit }: { onLogout: () => void; onExit: () => void }) {
  const { legends, clubs, updateLegend, resetLegend, getOverride } = useData();
  const [selectedId, setSelectedId] = useState(1);
  const [saved, setSaved] = useState(false);
  const [section, setSection] = useState<'league' | 'matches'>('league');

  const legend = legends.find((l) => l.id === selectedId);
  const override = getOverride(selectedId);

  const currentClubId = legend?.currentClubId ?? (legend?.nickname === 'RiNO' ? 'latvia' : null);
  const clubRole = legend?.clubRole ?? 'Игрок';
  const goals = legend?.goals ?? 0;
  const assists = legend?.assists ?? 0;
  const matches = legend?.matches ?? 0;
  const strengths = legend?.strengths ?? [];
  const biography = legend?.description ?? '';
  const achievements = legend?.achievements ?? [];

  const [newStrength, setNewStrength] = useState('');
  const [newAchievement, setNewAchievement] = useState('');

  const flashSaved = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const handleSaveField = (field: string, value: string | number | string[] | null) => {
    updateLegend(selectedId, { [field]: value } as never);
    flashSaved();
  };

  const handleAddStrength = () => {
    if (!newStrength.trim()) return;
    handleSaveField('strengths', [...strengths, newStrength.trim()]);
    setNewStrength('');
  };

  const handleRemoveStrength = (s: string) => {
    handleSaveField('strengths', strengths.filter((x) => x !== s));
  };

  const handleAddAchievement = () => {
    if (!newAchievement.trim()) return;
    handleSaveField('achievements', [...achievements, newAchievement.trim()]);
    setNewAchievement('');
  };

  const handleRemoveAchievement = (a: string) => {
    handleSaveField('achievements', achievements.filter((x) => x !== a));
  };

  if (!legend) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-rose-900/50 bg-gradient-to-br from-zinc-950 to-black p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-rose-700 to-rose-950 ring-1 ring-rose-500/40">
            <Shield className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-extrabold text-white">Админ-панель</h2>
            <p className="text-sm text-zinc-500">Управление почетными игроками</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onExit}
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 px-4 py-2.5 text-sm font-bold text-zinc-300 transition hover:border-rose-600 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" /> На сайт
          </button>
          <button
            onClick={onLogout}
            className="inline-flex items-center gap-2 rounded-lg border border-red-800/60 bg-red-950/40 px-4 py-2.5 text-sm font-bold text-red-300 transition hover:border-red-600 hover:bg-red-900/40 hover:text-red-200"
          >
            <LogOut className="h-4 w-4" /> Выйти из админки
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 rounded-2xl border border-zinc-800 bg-zinc-950/60 p-2">
        <button onClick={() => setSection('league')} className={`rounded-xl px-4 py-3 text-sm font-bold transition ${section === 'league' ? 'bg-rose-800 text-white shadow-lg shadow-rose-950/30' : 'text-zinc-500 hover:bg-zinc-900 hover:text-white'}`}>Игроки и легенды</button>
        <button onClick={() => setSection('matches')} className={`rounded-xl px-4 py-3 text-sm font-bold transition ${section === 'matches' ? 'bg-emerald-800 text-white shadow-lg shadow-emerald-950/30' : 'text-zinc-500 hover:bg-zinc-900 hover:text-white'}`}>Матчи СНГ Лиги</button>
      </div>

      {saved && (
        <div className="flex items-center gap-2 rounded-lg border border-emerald-700/40 bg-emerald-950/40 px-4 py-3 text-sm font-semibold text-emerald-300">
          <Save className="h-4 w-4" /> Изменения сохранены
        </div>
      )}

      {section === 'matches' ? <MatchManagement /> : <>
      <PlayerManagement />

      {/* Player selector */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
        <label className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
          <User className="h-4 w-4 text-rose-500" /> Выбор игрока
        </label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(Number(e.target.value))}
          className="w-full rounded-lg border border-zinc-700 bg-black/60 px-4 py-3 text-white outline-none transition focus:border-rose-600"
        >
          {legends.map((l) => (
            <option key={l.id} value={l.id}>
              {l.nickname} — {l.badge}
            </option>
          ))}
        </select>
      </section>

      {/* Current Club */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <Shield className="h-5 w-5 text-rose-500" /> Текущий клуб
        </h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-zinc-500">Клуб</label>
            <select
              value={currentClubId ?? ''}
              onChange={(e) => handleSaveField('currentClubId', e.target.value || null)}
              className="w-full rounded-lg border border-zinc-700 bg-black/60 px-4 py-2.5 text-white outline-none transition focus:border-rose-600"
            >
              <option value="">Не выбран</option>
              {clubs.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.country})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-zinc-500">Роль в клубе</label>
            <input
              type="text"
              value={clubRole}
              onChange={(e) => handleSaveField('clubRole', e.target.value)}
              placeholder="Игрок / Основатель"
              className="w-full rounded-lg border border-zinc-700 bg-black/60 px-4 py-2.5 text-white placeholder-zinc-600 outline-none transition focus:border-rose-600"
            />
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <Target className="h-5 w-5 text-rose-500" /> Статистика
        </h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <StatInput
            icon={<Target className="h-4 w-4" />}
            label="Голы"
            value={goals}
            onChange={(v) => handleSaveField('goals', v)}
          />
          <StatInput
            icon={<Hand className="h-4 w-4" />}
            label="Ассисты"
            value={assists}
            onChange={(v) => handleSaveField('assists', v)}
          />
          <StatInput
            icon={<Calendar className="h-4 w-4" />}
            label="Матчи"
            value={matches}
            onChange={(v) => handleSaveField('matches', v)}
          />
        </div>
      </section>

      {/* Strengths */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <Zap className="h-5 w-5 text-rose-500" /> Лучшие качества
        </h3>
        <div className="mb-3 flex flex-wrap gap-2">
          {strengths.map((s) => (
            <span
              key={s}
              className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-900/60 px-3 py-1.5 text-sm font-semibold text-zinc-200"
            >
              {s}
              <button
                onClick={() => handleRemoveStrength(s)}
                className="text-zinc-500 transition hover:text-red-400"
                aria-label="Удалить"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </span>
          ))}
          {strengths.length === 0 && <p className="text-sm text-zinc-600">Нет добавленных качеств</p>}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={newStrength}
            onChange={(e) => setNewStrength(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddStrength())}
            placeholder="Добавить качество (например: Видение игры)"
            className="flex-1 rounded-lg border border-zinc-700 bg-black/60 px-4 py-2.5 text-white placeholder-zinc-600 outline-none transition focus:border-rose-600"
          />
          <button
            onClick={handleAddStrength}
            className="inline-flex items-center gap-1.5 rounded-lg bg-rose-700 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-rose-600"
          >
            <Plus className="h-4 w-4" /> Добавить
          </button>
        </div>
      </section>

      {/* Biography */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <User className="h-5 w-5 text-rose-500" /> Биография
        </h3>
        <textarea
          value={biography}
          onChange={(e) => handleSaveField('biography', e.target.value)}
          rows={4}
          placeholder="Описание игрока..."
          className="w-full rounded-lg border border-zinc-700 bg-black/60 px-4 py-3 text-sm leading-relaxed text-white placeholder-zinc-600 outline-none transition focus:border-rose-600"
        />
      </section>

      {/* Achievements */}
      <section className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <Award className="h-5 w-5 text-rose-500" /> Достижения
        </h3>
        <div className="mb-3 space-y-2">
          {achievements.map((a, i) => (
            <div
              key={i}
              className="flex items-start justify-between gap-3 rounded-lg border border-zinc-800 bg-black/40 px-4 py-3"
            >
              <span className="text-sm leading-relaxed text-zinc-300">{a}</span>
              <button
                onClick={() => handleRemoveAchievement(a)}
                className="shrink-0 text-zinc-500 transition hover:text-red-400"
                aria-label="Удалить"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
          {achievements.length === 0 && <p className="text-sm text-zinc-600">Нет добавленных достижений</p>}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={newAchievement}
            onChange={(e) => setNewAchievement(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddAchievement())}
            placeholder="Добавить достижение..."
            className="flex-1 rounded-lg border border-zinc-700 bg-black/60 px-4 py-2.5 text-white placeholder-zinc-600 outline-none transition focus:border-rose-600"
          />
          <button
            onClick={handleAddAchievement}
            className="inline-flex items-center gap-1.5 rounded-lg bg-rose-700 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-rose-600"
          >
            <Plus className="h-4 w-4" /> Добавить
          </button>
        </div>
      </section>

      {/* Reset */}
      {override && (
        <button
          onClick={() => resetLegend(selectedId)}
          className="inline-flex items-center gap-2 rounded-lg border border-amber-800/50 bg-amber-950/30 px-4 py-2.5 text-sm font-bold text-amber-300 transition hover:border-amber-600 hover:bg-amber-900/30"
        >
          <RotateCcw className="h-4 w-4" /> Сбросить к оригиналу
        </button>
      )}
      </>}
    </div>
  );
}

function PlayerManagement() {
  const { players, clubs, addPlayer, updatePlayer, deletePlayer } = useData();
  const emptyForm: Omit<DirectoryPlayer, 'id'> = { name: '', position: 'MID', age: 18, height: '180 см', currentClub: 'Свободный агент', skills: [], goals: 0, assists: 0, matches: 0 };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [skillsText, setSkillsText] = useState('');

  const reset = () => { setForm(emptyForm); setSkillsText(''); setEditingId(null); };
  const save = () => {
    if (!form.name.trim()) return;
    const player = { ...form, name: form.name.trim(), skills: skillsText.split(',').map((skill) => skill.trim()).filter(Boolean) };
    if (editingId === null) addPlayer(player); else updatePlayer(editingId, player);
    reset();
  };
  const edit = (player: DirectoryPlayer) => { setEditingId(player.id); setForm(player); setSkillsText(player.skills.join(', ')); };

  return <section className="rounded-2xl border border-rose-900/50 bg-gradient-to-br from-zinc-950 to-black p-5 md:p-6">
    <div className="mb-5 flex items-center justify-between gap-3"><div><h3 className="flex items-center gap-2 text-xl font-bold text-white"><UsersRound className="h-5 w-5 text-rose-500" /> Игроки · Players Directory</h3><p className="mt-1 text-sm text-zinc-500">Добавляйте и обновляйте игроков общего каталога.</p></div>{editingId !== null && <button onClick={reset} className="text-sm font-semibold text-zinc-400 hover:text-white">Отмена</button>}</div>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      <Field label="Имя / Ник"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Например: RiNO" className={inputClass} /></Field>
      <Field label="Позиция"><input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} placeholder="ЦП, ЦЗ, НАП" className={inputClass} /></Field>
      <Field label="Возраст"><input type="number" min="1" value={form.age} onChange={(e) => setForm({ ...form, age: Number(e.target.value) || 0 })} className={inputClass} /></Field>
      <Field label="Рост"><input value={form.height} onChange={(e) => setForm({ ...form, height: e.target.value })} placeholder="185 см" className={inputClass} /></Field>
      <Field label="Клуб"><select value={form.currentClub} onChange={(e) => setForm({ ...form, currentClub: e.target.value })} className={inputClass}><option>Свободный агент</option>{clubs.map((club) => <option key={club.id}>{club.name}</option>)}</select></Field>
      <Field label="Качества через запятую"><input value={skillsText} onChange={(e) => setSkillsText(e.target.value)} placeholder="Дриблинг, Удар" className={inputClass} /></Field>
      <StatInput icon={<Target className="h-4 w-4" />} label="Голы" value={form.goals} onChange={(value) => setForm({ ...form, goals: value })} />
      <StatInput icon={<Hand className="h-4 w-4" />} label="Ассисты" value={form.assists} onChange={(value) => setForm({ ...form, assists: value })} />
      <StatInput icon={<Calendar className="h-4 w-4" />} label="Матчи" value={form.matches} onChange={(value) => setForm({ ...form, matches: value })} />
    </div>
    <button onClick={save} className="mt-4 inline-flex items-center gap-2 rounded-lg bg-rose-700 px-5 py-3 text-sm font-bold text-white transition hover:bg-rose-600"><Save className="h-4 w-4" /> {editingId === null ? 'Добавить игрока' : 'Сохранить игрока'}</button>
    <div className="mt-6 space-y-2 border-t border-zinc-800 pt-5">{players.map((player) => <div key={player.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-zinc-800 bg-black/40 px-4 py-3"><div><p className="font-bold text-white">{player.name} <span className="ml-2 text-xs font-semibold text-rose-400">{player.position}</span></p><p className="text-xs text-zinc-500">{player.currentClub} · {player.goals} голов · {player.matches} матчей</p></div><div className="flex gap-2"><button onClick={() => edit(player)} className="inline-flex items-center gap-1 rounded-md border border-zinc-700 px-3 py-2 text-xs font-bold text-zinc-300 hover:border-rose-600 hover:text-white"><Pencil className="h-3.5 w-3.5" /> Изменить</button><button onClick={() => deletePlayer(player.id)} className="rounded-md border border-red-900/60 p-2 text-red-400 hover:bg-red-950/40" aria-label={`Удалить ${player.name}`}><Trash2 className="h-4 w-4" /></button></div></div>)}</div>
  </section>;
}

function MatchManagement() {
  const { matches, players, clubs, addMatch, updateMatch, deleteMatch } = useData();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [status, setStatus] = useState<'scheduled' | 'completed'>('scheduled');
  const [tournament, setTournament] = useState('CIS League · Тур 1');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 16));
  const [payload, setPayload] = useState<MatchPayload>(emptyMatchPayload());
  const [side, setSide] = useState<MatchSideKey>('home');
  const [playerName, setPlayerName] = useState('');
  const [playerPosition, setPlayerPosition] = useState('ГК');
  const [playerRating, setPlayerRating] = useState(7.0);
  const [playerNumber, setPlayerNumber] = useState(1);
  const [isBench, setIsBench] = useState(false);
  const [eventType, setEventType] = useState<MatchEvent['type']>('goal');
  const [eventMinute, setEventMinute] = useState(1);
  const [eventPlayer, setEventPlayer] = useState('');
  const [eventAssist, setEventAssist] = useState('');
  const [eventCard, setEventCard] = useState<'yellow' | 'red'>('yellow');
  const [eventIn, setEventIn] = useState('');
  const [eventOut, setEventOut] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const reset = () => { setEditingId(null); setStatus('scheduled'); setTournament('CIS League · Тур 1'); setDate(new Date().toISOString().slice(0, 16)); setPayload(emptyMatchPayload()); setMessage(''); };
  const updateSide = (key: MatchSideKey, patch: Partial<MatchPayload['home']>) => setPayload((current) => ({ ...current, [key]: { ...current[key], ...patch } }));
  const setTeam = (key: MatchSideKey, field: 'name' | 'logo', value: string) => updateSide(key, { team: { ...payload[key].team, [field]: value } });
  const takenPositions = new Set(payload[side].lineup.map((player) => player.position));
  const positionTaken = takenPositions.has(playerPosition);
  const addRosterPlayer = () => {
    if (!playerName.trim()) return;
    if (!isBench && positionTaken) { setMessage(`Позиция «${playerPosition}» уже занята в составе.`); return; }
    setMessage('');
    const coords = positionCoordinate(playerPosition, side);
    const player: MatchPlayer = { id: `${Date.now()}-${Math.random()}`, name: playerName.trim(), number: Math.min(99, Math.max(0, playerNumber)), position: playerPosition, rating: Math.min(10, Math.max(1, playerRating)), x: coords.x, y: coords.y };
    updateSide(side, isBench ? { bench: [...payload[side].bench, player] } : { lineup: [...payload[side].lineup, player] });
    setPlayerName('');
  };
  const removePlayer = (key: MatchSideKey, playerId: string, fromBench: boolean) => updateSide(key, fromBench ? { bench: payload[key].bench.filter((player) => player.id !== playerId) } : { lineup: payload[key].lineup.filter((player) => player.id !== playerId) });
  const addEvent = () => {
    if (eventType === 'substitution' && (!eventIn.trim() || !eventOut.trim())) return;
    if (eventType !== 'substitution' && !eventPlayer.trim()) return;
    const event: MatchEvent = { id: `${Date.now()}-${Math.random()}`, type: eventType, minute: Math.max(1, eventMinute), side, player: eventPlayer.trim(), assist: eventAssist.trim() || undefined, card: eventType === 'card' ? eventCard : undefined, playerIn: eventType === 'substitution' ? eventIn.trim() : undefined, playerOut: eventType === 'substitution' ? eventOut.trim() : undefined };
    setPayload((current) => ({ ...current, events: [...current.events, event].sort((a, b) => a.minute - b.minute), home: { ...current.home, score: current.home.score + (eventType === 'goal' && side === 'home' ? 1 : 0) }, away: { ...current.away, score: current.away.score + (eventType === 'goal' && side === 'away' ? 1 : 0) } }));
    setEventPlayer(''); setEventAssist(''); setEventIn(''); setEventOut('');
  };
  const save = async () => {
    if (!payload.home.team.name.trim() || !payload.away.team.name.trim()) return setMessage('Укажите обе команды.');
    setSaving(true); setMessage('');
    try { const record = { status, match_date: new Date(date).toISOString(), tournament: tournament.trim() || 'CIS League', payload }; if (editingId) await updateMatch(editingId, record); else await addMatch(record); reset(); setMessage('Матч сохранён.'); } catch { setMessage('Не удалось сохранить матч.'); } finally { setSaving(false); }
  };
  const edit = (match: MatchRecord) => { setEditingId(match.id); setStatus(match.status); setTournament(match.tournament); setDate(match.match_date.slice(0, 16)); setPayload(match.payload); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const teamOptions = clubs.map((club) => <option key={club.id} value={club.name}>{club.name}</option>);
  const selectedClub = clubs.find((club) => club.name === payload[side].team.name);
  const rosterOptions = players.map((player) => player.name);
  return <section className="rounded-2xl border border-emerald-900/50 bg-gradient-to-br from-zinc-950 to-black p-5 md:p-6">
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3"><div><h3 className="flex items-center gap-2 text-xl font-bold text-white"><Shield className="h-5 w-5 text-emerald-500" /> Матчи СНГ Лиги · Match Center</h3><p className="mt-1 text-sm text-zinc-500">Создавайте протоколы с составами, событиями и оценками игроков.</p></div>{editingId && <button onClick={reset} className="text-sm font-semibold text-zinc-400 hover:text-white">Новый матч</button>}</div>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><Field label="Статус"><select value={status} onChange={(e) => setStatus(e.target.value as 'scheduled' | 'completed')} className={inputClass}><option value="scheduled">Запланирован</option><option value="completed">Завершён</option></select></Field><Field label="Формат"><select value={payload.format} onChange={(e) => { const format = e.target.value as MatchFormat; setPayload({ ...payload, format, formation: formationOptions[format][0] }); }} className={inputClass}>{matchFormats.map((format) => <option key={format}>{format}</option>)}</select></Field><Field label="Схема"><select value={payload.formation ?? formationOptions[payload.format][0]} onChange={(e) => setPayload({ ...payload, formation: e.target.value })} className={inputClass}>{formationOptions[payload.format].map((formation) => <option key={formation}>{formation}</option>)}</select></Field><Field label="Турнир / тур"><input value={tournament} onChange={(e) => setTournament(e.target.value)} className={inputClass} /></Field><Field label="Дата и время"><input type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} className={inputClass} /></Field></div>
    <div className="mt-5 grid gap-4 md:grid-cols-2"><TeamEditor label="Хозяева" side="home" payload={payload} setTeam={setTeam} updateSide={updateSide} teamOptions={teamOptions} /><TeamEditor label="Гости" side="away" payload={payload} setTeam={setTeam} updateSide={updateSide} teamOptions={teamOptions} /></div>
    <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_1fr]">
      <div className="rounded-xl border border-zinc-800 bg-black/30 p-4"><h4 className="mb-3 font-bold text-white">Состав и скамейка</h4><div className="mb-3 flex gap-2"><button onClick={() => setSide('home')} className={`flex-1 rounded-lg px-3 py-2 text-sm font-bold ${side === 'home' ? 'bg-emerald-800 text-white' : 'bg-zinc-900 text-zinc-500'}`}>Хозяева</button><button onClick={() => setSide('away')} className={`flex-1 rounded-lg px-3 py-2 text-sm font-bold ${side === 'away' ? 'bg-emerald-800 text-white' : 'bg-zinc-900 text-zinc-500'}`}>Гости</button></div><div className="grid gap-2 sm:grid-cols-2"><select value={playerName} onChange={(e) => setPlayerName(e.target.value)} className={inputClass}><option value="">Игрок из состава «{selectedClub?.name ?? '—'}»</option>{rosterOptions.map((nickname) => <option key={nickname} value={nickname}>{nickname}</option>)}</select><input value={playerName} onChange={(e) => setPlayerName(e.target.value)} placeholder="или свой ник" className={inputClass} /><input type="number" min="0" max="99" value={playerNumber} onChange={(e) => setPlayerNumber(Number(e.target.value))} placeholder="Номер" className={inputClass} /><select value={playerPosition} onChange={(e) => setPlayerPosition(e.target.value)} className={inputClass}>{matchPositions.map((position) => { const taken = takenPositions.has(position); return <option key={position} value={position} disabled={taken && !isBench}>{position} · {positionLabelsFull[position]}{taken ? ' (занято)' : ''}</option>; })}</select><input type="number" min="1" max="10" step="0.1" value={playerRating} onChange={(e) => setPlayerRating(Number(e.target.value))} placeholder="Оценка" className={inputClass} /><label className="flex items-center gap-2 rounded-lg border border-zinc-700 px-3 text-sm text-zinc-300"><input type="checkbox" checked={isBench} onChange={(e) => setIsBench(e.target.checked)} /> Скамейка</label></div><button onClick={addRosterPlayer} disabled={!isBench && positionTaken} className="mt-3 w-full rounded-lg bg-emerald-800 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-40">Добавить игрока</button>{message && <p className="mt-2 text-xs font-semibold text-rose-400">{message}</p>}<RosterList label="Старт" players={payload[side].lineup} onRemove={(id) => removePlayer(side, id, false)} /><RosterList label="Скамейка" players={payload[side].bench} onRemove={(id) => removePlayer(side, id, true)} /><AdminLineupBoard side={side} payload={payload} setPayload={setPayload} /></div>
      <div className="rounded-xl border border-zinc-800 bg-black/30 p-4"><h4 className="mb-3 font-bold text-white">Конструктор событий</h4><div className="grid gap-2 sm:grid-cols-2"><select value={eventType} onChange={(e) => setEventType(e.target.value as MatchEvent['type'])} className={inputClass}><option value="goal">Гол</option><option value="card">Карточка</option><option value="substitution">Замена</option></select><select value={side} onChange={(e) => setSide(e.target.value as MatchSideKey)} className={inputClass}><option value="home">Хозяева</option><option value="away">Гости</option></select><input type="number" min="1" value={eventMinute} onChange={(e) => setEventMinute(Number(e.target.value))} placeholder="Минута" className={inputClass} />{eventType === 'card' ? <select value={eventCard} onChange={(e) => setEventCard(e.target.value as 'yellow' | 'red')} className={inputClass}><option value="yellow">Жёлтая</option><option value="red">Красная</option></select> : eventType === 'substitution' ? <><input value={eventOut} onChange={(e) => setEventOut(e.target.value)} placeholder="Игрок ушёл" className={inputClass} /><input value={eventIn} onChange={(e) => setEventIn(e.target.value)} placeholder="Игрок вышел" className={inputClass} /></> : <><input value={eventPlayer} onChange={(e) => setEventPlayer(e.target.value)} placeholder="Автор гола" className={inputClass} /><input value={eventAssist} onChange={(e) => setEventAssist(e.target.value)} placeholder="Ассистент" className={inputClass} /></>}</div><button onClick={addEvent} className="mt-3 w-full rounded-lg border border-amber-700/50 bg-amber-950/30 px-4 py-2.5 text-sm font-bold text-amber-200 hover:bg-amber-900/40">Добавить событие</button><div className="mt-4 space-y-2">{payload.events.map((event) => <div key={event.id} className="flex items-center justify-between rounded-lg border border-zinc-800 px-3 py-2 text-xs text-zinc-300"><span>{event.minute}' · {event.type === 'goal' ? `Гол: ${event.player}` : event.type === 'card' ? `Карточка: ${event.player}` : `Замена: ${event.playerOut} → ${event.playerIn}`}</span><button onClick={() => setPayload({ ...payload, events: payload.events.filter((item) => item.id !== event.id) })} className="text-zinc-500 hover:text-red-400"><X className="h-4 w-4" /></button></div>)}</div></div>
    </div>
    <div className="mt-4 grid gap-3 sm:grid-cols-2"><Field label="Игрок матча"><input value={payload.motm ?? ''} onChange={(e) => setPayload({ ...payload, motm: e.target.value })} placeholder="Например: RiNO" className={inputClass} /></Field><Field label="Заметка к протоколу"><input value={payload.notes ?? ''} onChange={(e) => setPayload({ ...payload, notes: e.target.value })} placeholder="Краткое резюме матча" className={inputClass} /></Field></div>
    <div className="mt-4 flex flex-wrap items-center gap-3"><button onClick={() => void save()} disabled={saving} className="rounded-lg bg-emerald-700 px-5 py-3 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-50">{saving ? 'Сохраняем...' : editingId ? 'Сохранить изменения' : 'Создать матч'}</button>{message && <span className="text-sm font-semibold text-emerald-300">{message}</span>}</div>
    <div className="mt-6 space-y-2 border-t border-zinc-800 pt-5">{matches.map((match) => <div key={match.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-zinc-800 bg-black/40 px-4 py-3"><div><p className="font-bold text-white">{match.payload.home.team.name} {match.payload.home.score}:{match.payload.away.score} {match.payload.away.team.name}</p><p className="text-xs text-zinc-500">{match.tournament} · {new Date(match.match_date).toLocaleDateString('ru-RU')}</p></div><div className="flex gap-2"><button onClick={() => edit(match)} className="rounded-md border border-zinc-700 px-3 py-2 text-xs font-bold text-zinc-300 hover:border-emerald-600 hover:text-white">Изменить</button><button onClick={() => void deleteMatch(match.id)} className="rounded-md border border-red-900/60 px-3 py-2 text-xs font-bold text-red-400 hover:bg-red-950/40">Удалить</button></div></div>)}</div>
  </section>;
}

function TeamEditor({ label, side, payload, setTeam, updateSide, teamOptions }: { label: string; side: MatchSideKey; payload: MatchPayload; setTeam: (side: MatchSideKey, field: 'name' | 'logo', value: string) => void; updateSide: (side: MatchSideKey, patch: Partial<MatchPayload['home']>) => void; teamOptions: JSX.Element[] }) { return <div className="rounded-xl border border-zinc-800 bg-black/30 p-4"><h4 className="mb-3 font-bold text-white">{label}</h4><div className="grid gap-2 sm:grid-cols-2"><select value={payload[side].team.name} onChange={(e) => setTeam(side, 'name', e.target.value)} className={inputClass}><option value="">Выбрать клуб</option>{teamOptions}</select><input value={payload[side].team.logo} onChange={(e) => setTeam(side, 'logo', e.target.value)} placeholder="Ссылка на логотип" className={inputClass} /><input type="number" min="0" value={payload[side].score} onChange={(e) => updateSide(side, { score: Number(e.target.value) || 0 })} placeholder="Счёт" className={inputClass} /></div></div>; }
function RosterList({ label, players, onRemove }: { label: string; players: MatchPlayer[]; onRemove: (id: string) => void }) { return <div className="mt-4"><p className="mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">{label}</p><div className="space-y-1">{players.map((player) => <div key={player.id} className="flex items-center justify-between rounded-md bg-zinc-900/60 px-2.5 py-1.5 text-xs"><span className="text-zinc-300">{player.name} · {player.position}</span><span className="flex items-center gap-2 font-bold text-emerald-400">{player.rating.toFixed(1)}<button onClick={() => onRemove(player.id)} className="text-zinc-600 hover:text-red-400"><X className="h-3.5 w-3.5" /></button></span></div>)}</div></div>; }

function adminRatingClass(rating: number) {
  if (rating < 6) return 'bg-red-500 text-white';
  if (rating < 7) return 'bg-yellow-400 text-black';
  if (rating < 8) return 'bg-lime-400 text-black';
  if (rating < 9) return 'bg-emerald-800 text-white';
  if (rating < 10) return 'bg-sky-400 text-slate-950';
  return 'bg-blue-600 text-white';
}

function AdminLineupBoard({ side, payload, setPayload }: { side: MatchSideKey; payload: MatchPayload; setPayload: (value: React.SetStateAction<MatchPayload>) => void }) {
  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null);
  const players = [...payload[side].lineup, ...payload[side].bench];

  const placePlayer = (playerId: string, event: React.MouseEvent<HTMLDivElement> | React.DragEvent<HTMLDivElement>) => {
    const field = event.currentTarget;
    const bounds = field.getBoundingClientRect();
    const x = Math.max(5, Math.min(95, ((event.clientX - bounds.left) / bounds.width) * 100));
    const y = Math.max(7, Math.min(93, ((event.clientY - bounds.top) / bounds.height) * 100));
    setPayload((current) => ({ ...current, [side]: { ...current[side], lineup: [...current[side].lineup.filter((item) => item.id !== playerId), { ...players.find((item) => item.id === playerId)!, x, y }], bench: current[side].bench.filter((item) => item.id !== playerId) } }));
    setSelectedPlayerId(null);
  };

  const handleFieldClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (selectedPlayerId) placePlayer(selectedPlayerId, event);
  };
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const playerId = event.dataTransfer.getData('player-id');
    if (playerId) placePlayer(playerId, event);
  };

  return <div className="mt-5 rounded-xl border border-emerald-900/60 bg-zinc-950/70 p-3"><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div><p className="text-sm font-bold text-white">Расстановка на поле</p><p className="text-xs text-zinc-500">Выберите игрока, затем нажмите на поле, или перетащите его.</p></div><span className="rounded-full border border-emerald-800/60 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-400">{payload.formation ?? 'Схема'}</span></div><div className="mb-3 flex flex-wrap gap-1.5">{players.map((player) => <button key={player.id} draggable onDragStart={(event) => event.dataTransfer.setData('player-id', player.id)} onClick={() => setSelectedPlayerId(player.id)} className={`rounded-md border px-2 py-1 text-[10px] font-bold transition ${selectedPlayerId === player.id ? 'border-emerald-400 bg-emerald-800 text-white' : 'border-zinc-700 bg-black/40 text-zinc-300 hover:border-emerald-700'}`}>{player.number ?? '—'} · {player.name}{payload[side].bench.some((item) => item.id === player.id) ? ' · запас' : ''}</button>)}</div><div onClick={handleFieldClick} onDragOver={(event) => event.preventDefault()} onDrop={handleDrop} className="relative aspect-[4/3] cursor-crosshair overflow-hidden rounded-lg border-2 border-emerald-600/70 bg-[linear-gradient(90deg,rgba(255,255,255,.07)_1px,transparent_1px),linear-gradient(rgba(255,255,255,.07)_1px,transparent_1px),linear-gradient(135deg,#166534,#15803d,#166534)] bg-[size:10%_20%,10%_20%,100%_100%]"><div className="absolute inset-2 rounded border border-white/35" /><div className="absolute left-1/2 top-2 bottom-2 w-px -translate-x-1/2 bg-white/25" /><div className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/30" />{payload[side].lineup.map((player) => <div key={player.id} className="absolute z-10 -translate-x-1/2 -translate-y-1/2 text-center" style={{ left: `${player.x}%`, top: `${player.y}%` }}><div className="relative flex h-9 w-9 items-center justify-center rounded-full border-2 border-white/80 bg-slate-950 text-[10px] font-black text-white shadow-lg"><span className="absolute -top-3 text-[8px] text-white">{player.position}</span>{player.number ?? '—'}<span className={`absolute -right-3 -top-2 rounded-full px-1 text-[8px] font-black ${adminRatingClass(player.rating)}`}>{player.rating.toFixed(1)}</span></div><span className="mt-1 block max-w-20 truncate rounded bg-black/70 px-1 text-[9px] font-bold text-white">{player.name}</span></div>)}</div></div>;
}

const inputClass = 'w-full rounded-lg border border-zinc-700 bg-black/60 px-4 py-2.5 text-white placeholder-zinc-600 outline-none transition focus:border-emerald-600';
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <div><label className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-zinc-500">{label}</label>{children}</div>; }

function StatInput({
  icon,
  label,
  value,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <label className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-zinc-500">
        {icon} {label}
      </label>
      <input
        type="number"
        min={0}
        value={value}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="w-full rounded-lg border border-zinc-700 bg-black/60 px-4 py-2.5 text-lg font-bold text-white outline-none transition focus:border-rose-600"
      />
    </div>
  );
}
