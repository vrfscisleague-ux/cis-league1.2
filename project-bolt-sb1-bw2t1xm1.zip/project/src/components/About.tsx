import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Footprints,
  Gamepad2,
  Globe,
  Goal,
  Flag,
  Scale,
  ShieldAlert,
  Trophy,
  Users,
  Video,
  type LucideIcon,
} from 'lucide-react';
import { aboutInfo, type RuleIconName } from '@/data/mockData';

const ruleIcons: Record<RuleIconName, LucideIcon> = {
  shield: ShieldAlert,
  footprints: Footprints,
  goal: Goal,
  flag: Flag,
  alert: AlertTriangle,
  scale: Scale,
  trophy: Trophy,
  users: Users,
  globe: Globe,
  video: Video,
  activity: Activity,
  file: FileText,
};

export default function About() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <p className="text-sm font-bold uppercase tracking-[0.25em] text-red-500">CIS League</p>
        <h2 className="mt-2 text-3xl font-extrabold text-white md:text-4xl">О лиге и правила</h2>
        <p className="mx-auto mt-2 max-w-2xl text-zinc-500">
          Официальный регламент VRFS CIS League для команд, игроков и судей.
        </p>
      </div>

      <section className="rounded-2xl border border-red-900/40 bg-gradient-to-br from-neutral-900/90 to-black/80 p-6 md:p-8">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-950/70 ring-1 ring-red-600/40">
            <Gamepad2 className="h-6 w-6 text-red-400" />
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-red-500">Дисциплина</p>
            <h3 className="text-xl font-bold text-white">Что такое VRFS?</h3>
          </div>
        </div>
        <p className="mt-5 max-w-4xl leading-relaxed text-neutral-300">{aboutInfo.whatIsVRFS}</p>
      </section>

      <section className="rounded-2xl border border-red-900/40 bg-black/60 p-5 md:p-8">
        <div className="flex items-center gap-3 border-b border-red-900/30 pb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-950/70 ring-1 ring-red-600/40">
            <ShieldAlert className="h-6 w-6 text-red-400" />
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-red-500">Раздел 1</p>
            <h3 className="text-xl font-bold text-white md:text-2xl">Официальный регламент и правила игры</h3>
          </div>
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {aboutInfo.ruleSections.map((section, index) => {
            const Icon = ruleIcons[section.icon];
            return (
              <article
                key={section.title}
                className="rounded-xl border border-red-900/40 bg-neutral-900/80 p-5 transition-all hover:border-red-600/60"
              >
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-black/70 text-red-500 ring-1 ring-red-900/60">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-red-600">1.{index + 1}</p>
                    <h4 className="mt-1 text-lg font-bold text-red-500">{section.title}</h4>
                  </div>
                </div>
                <ul className="mt-4 space-y-2 text-sm leading-relaxed text-neutral-300">
                  {section.points.map((point) => (
                    <li key={point} className="flex gap-2.5">
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-red-500" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>
      </section>

      <section className="rounded-2xl border border-red-900/40 bg-gradient-to-br from-red-950/30 to-black/80 p-5 md:p-8">
        <div className="flex items-center gap-3 border-b border-red-900/30 pb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-950/70 ring-1 ring-red-600/40">
            <Users className="h-6 w-6 text-red-400" />
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-red-500">Раздел 2</p>
            <h3 className="text-xl font-bold text-white md:text-2xl">Как подать заявку</h3>
          </div>
        </div>

        <div className="mt-6 grid gap-3 md:grid-cols-2">
          {aboutInfo.howToJoin.map((step, index) => (
            <div
              key={step}
              className="flex gap-4 rounded-xl border border-red-900/40 bg-neutral-900/80 p-4 transition-all hover:border-red-600/60"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-red-600 text-sm font-extrabold text-white shadow-lg shadow-red-950/50">
                {index + 1}
              </span>
              <p className="self-center text-sm leading-relaxed text-neutral-300">{step}</p>
            </div>
          ))}
        </div>

        <a
          href="https://discord.gg/7jqPHqnMCJ"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 px-6 py-4 text-base font-extrabold text-white shadow-[0_0_24px_rgba(220,38,38,0.45)] transition-all hover:bg-red-500 hover:shadow-[0_0_34px_rgba(239,68,68,0.65)] sm:w-auto"
        >
          <CheckCircle2 className="h-5 w-5" />
          Подать заявку в Discord
        </a>
      </section>
    </div>
  );
}
