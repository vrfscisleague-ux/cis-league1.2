import { useMemo, useState } from 'react';
import { CalendarDays, ChevronRight, CircleAlert, Crown, Filter, Goal, RefreshCw, Shield, X, Zap } from 'lucide-react';
import { useData } from '@/context/DataContext';
import type { MatchEvent, MatchRecord, MatchSideKey } from '@/data/matches';
import { formatMatchDate, getMatchStats } from '@/data/matches';

function TeamLogo({ src, name, className = 'h-12 w-12' }: { src: string; name: string; className?: string }) {
  return src ? <img src={src} alt={name} className={`${className} rounded-xl object-contain`} /> : <div className={`${className} flex items-center justify-center rounded-xl bg-zinc-800 text-sm font-black text-zinc-400`}>{name.slice(0, 2).toUpperCase()}</div>;
}

export default function MatchCenter() {
  const { matches, matchesLoading, matchesError } = useData();
  const [selected, setSelected] = useState<MatchRecord | null>(null);
  const [status, setStatus] = useState('all');
  const [tournament, setTournament] = useState('all');
  const [date, setDate] = useState('');
  const tournaments = [...new Set(matches.map((match) => match.tournament))].sort();
  const filtered = useMemo(() => matches.filter((match) => (
    (status === 'all' || match.status === status) &&
    (tournament === 'all' || match.tournament === tournament) &&
    (!date || match.match_date.slice(0, 10) === date)
  )), [matches, status, tournament, date]);
  const stats = getMatchStats(matches);

  return <div className="space-y-8">
    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div><div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-950 ring-1 ring-emerald-400/30"><Shield className="h-7 w-7 text-white" /></div><h2 className="text-3xl font-extrabold text-white md:text-4xl">Матчи СНГ Лиги</h2><p className="mt-2 max-w-2xl text-zinc-500">Match Center · протоколы, составы, оценки и ключевые события матчей.</p></div>
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950/60 px-4 py-3 text-sm text-zinc-400"><span className="font-bold text-white">{matches.length}</span> матчей · <span className="font-bold text-emerald-400">{[...stats.values()].reduce((sum, value) => sum + value.goals, 0)}</span> голов</div>
    </div>
    <div className="grid gap-3 rounded-2xl border border-zinc-800 bg-zinc-950/60 p-4 md:grid-cols-[1fr_1fr_180px_160px]">
      <label className="flex items-center gap-2 rounded-lg border border-zinc-700 bg-black/50 px-3"><Filter className="h-4 w-4 text-emerald-500" /><select value={status} onChange={(e) => setStatus(e.target.value)} className="w-full bg-transparent py-2.5 text-white outline-none"><option value="all">Все статусы</option><option value="completed">Сыгранные</option><option value="scheduled">Запланированные</option></select></label>
      <select value={tournament} onChange={(e) => setTournament(e.target.value)} className="rounded-lg border border-zinc-700 bg-black/50 px-3 py-2.5 text-white outline-none"><option value="all">Все турниры и туры</option>{tournaments.map((item) => <option key={item}>{item}</option>)}</select>
      <label className="relative"><CalendarDays className="absolute left-3 top-3 h-4 w-4 text-zinc-500" /><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-lg border border-zinc-700 bg-black/50 py-2.5 pl-10 pr-2 text-white outline-none" /></label>
      <button onClick={() => { setStatus('all'); setTournament('all'); setDate(''); }} className="rounded-lg border border-zinc-700 px-3 py-2.5 text-sm font-bold text-zinc-300 transition hover:border-emerald-600 hover:text-white">Сбросить</button>
    </div>
    {matchesLoading && <div className="flex items-center justify-center gap-3 rounded-2xl border border-zinc-800 p-12 text-zinc-400"><RefreshCw className="h-5 w-5 animate-spin text-emerald-500" /> Загружаем матчи...</div>}
    {matchesError && <div className="flex items-center gap-3 rounded-2xl border border-red-900/50 bg-red-950/20 p-5 text-red-300"><CircleAlert className="h-5 w-5" /> {matchesError}</div>}
    {!matchesLoading && filtered.length === 0 && <div className="rounded-2xl border border-dashed border-zinc-700 p-14 text-center text-zinc-500">Матчей по выбранным фильтрам пока нет.</div>}
    <div className="grid gap-4 lg:grid-cols-2">
      {filtered.map((match) => <MatchCard key={match.id} match={match} onOpen={() => setSelected(match)} />)}
    </div>
    {selected && <MatchDetails match={selected} onClose={() => setSelected(null)} />}
  </div>;
}

function MatchCard({ match, onOpen }: { match: MatchRecord; onOpen: () => void }) {
  const { home, away } = match.payload;
  return <button onClick={onOpen} className="group w-full rounded-2xl border border-zinc-800 bg-gradient-to-br from-zinc-950 to-black p-5 text-left transition hover:border-emerald-700/70 hover:shadow-xl hover:shadow-emerald-950/20">
    <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-zinc-500"><span>{match.tournament}</span><span className={match.status === 'completed' ? 'text-emerald-400' : 'text-amber-400'}>{match.status === 'completed' ? 'Завершён' : 'Запланирован'}</span></div>
    <div className="mt-5 grid grid-cols-[1fr_auto_1fr] items-center gap-3"><div className="flex flex-col items-center gap-2 text-center"><TeamLogo src={home.team.logo} name={home.team.name} /><strong className="text-sm text-white">{home.team.name || 'Хозяева'}</strong></div><div className="text-center"><div className="text-3xl font-black text-white">{match.status === 'completed' ? `${home.score} : ${away.score}` : '— : —'}</div><p className="mt-1 text-xs text-zinc-500">{formatMatchDate(match.match_date)}</p></div><div className="flex flex-col items-center gap-2 text-center"><TeamLogo src={away.team.logo} name={away.team.name} /><strong className="text-sm text-white">{away.team.name || 'Гости'}</strong></div></div>
    <div className="mt-5 flex items-center justify-between border-t border-zinc-800 pt-3 text-xs text-zinc-500"><span>{match.payload.format} · {match.payload.events.length} событий</span><span className="flex items-center gap-1 font-bold text-emerald-400 transition group-hover:gap-2">Открыть протокол <ChevronRight className="h-4 w-4" /></span></div>
  </button>;
}

function MatchDetails({ match, onClose }: { match: MatchRecord; onClose: () => void }) {
  const { home, away, events, motm } = match.payload;
  const eventsSorted = [...events].sort((a, b) => a.minute - b.minute);
  return <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 p-3 backdrop-blur-sm md:p-8" onClick={onClose}><div className="mx-auto max-w-6xl rounded-2xl border border-emerald-900/50 bg-zinc-950 shadow-2xl" onClick={(e) => e.stopPropagation()}>
    <div className="relative overflow-hidden rounded-t-2xl bg-gradient-to-br from-emerald-950 via-zinc-950 to-black p-6 md:p-8"><button onClick={onClose} className="absolute right-4 top-4 rounded-lg p-2 text-zinc-500 hover:bg-white/10 hover:text-white"><X /></button><p className="text-center text-xs font-bold uppercase tracking-widest text-emerald-400">{match.tournament} · {match.payload.format} · {match.payload.formation ?? 'Схема'} · {formatMatchDate(match.match_date)}</p><div className="mt-6 grid grid-cols-[1fr_auto_1fr] items-center gap-4"><TeamSummary side={home} score={home.score} /><div className="text-4xl font-black text-white">{home.score} : {away.score}</div><TeamSummary side={away} score={away.score} /></div>{motm && <div className="mx-auto mt-6 flex w-fit items-center gap-2 rounded-full border border-amber-700/50 bg-amber-950/40 px-4 py-2 text-sm font-bold text-amber-200"><Crown className="h-4 w-4 text-amber-400" /> Игрок матча: {motm}</div>}</div>
    <div className="grid gap-8 p-5 md:p-8 lg:grid-cols-[1.2fr_.8fr]"> <div><h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white"><Shield className="h-5 w-5 text-emerald-500" /> Составы и оценки</h3><div className="grid gap-4 md:grid-cols-2"><Lineup side={home} sideKey="home" /><Lineup side={away} sideKey="away" /></div></div><div><h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-white"><Zap className="h-5 w-5 text-amber-400" /> Хронология</h3><div className="space-y-2">{eventsSorted.length ? eventsSorted.map((event) => <EventRow key={event.id} event={event} homeName={home.team.name} />) : <p className="rounded-xl border border-dashed border-zinc-700 p-5 text-sm text-zinc-500">События не добавлены.</p>}</div></div></div>
    {match.payload.notes && <div className="mx-5 mb-6 rounded-xl border border-zinc-800 bg-black/40 p-4 text-sm leading-relaxed text-zinc-400 md:mx-8">{match.payload.notes}</div>}
  </div></div>;
}

function TeamSummary({ side, score }: { side: MatchRecord['payload']['home']; score: number }) { return <div className="flex flex-col items-center gap-2 text-center"><TeamLogo src={side.team.logo} name={side.team.name} className="h-16 w-16" /><strong className="text-white">{side.team.name}</strong><span className="text-xs text-zinc-500">{score} гол.</span></div>; }
function ratingClass(rating: number) {
  if (rating < 6) return 'bg-red-500 text-white';
  if (rating < 7) return 'bg-yellow-400 text-black';
  if (rating < 8) return 'bg-lime-400 text-black';
  if (rating < 9) return 'bg-emerald-800 text-white';
  if (rating < 10) return 'bg-sky-400 text-slate-950';
  return 'bg-blue-600 text-white';
}

function Lineup({ side, sideKey }: { side: MatchRecord['payload']['home']; sideKey: MatchSideKey }) {
  return <div><div className="relative aspect-[4/5] overflow-hidden rounded-xl border border-emerald-700/70 bg-[linear-gradient(90deg,rgba(255,255,255,.04)_1px,transparent_1px),linear-gradient(rgba(255,255,255,.04)_1px,transparent_1px),linear-gradient(135deg,#166534,#15803d,#166534)] bg-[size:25%_25%,25%_25%,100%_100%] shadow-inner"><div className="absolute inset-3 rounded-lg border-2 border-white/35" /><div className="absolute left-1/2 top-3 bottom-3 w-px -translate-x-1/2 bg-white/25" /><div className="absolute left-1/2 top-1/2 h-20 w-20 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/30" /><div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/70" />{side.lineup.map((player) => <div key={player.id} className="absolute z-10 -translate-x-1/2 -translate-y-1/2 text-center" style={{ left: `${player.x}%`, top: `${player.y}%` }}><div className="relative mx-auto flex h-10 w-10 items-center justify-center rounded-full border-2 border-white/80 bg-slate-950/90 text-xs font-black text-white shadow-lg"><span className="absolute -top-1.5 text-[8px] font-bold text-white/70">{player.position}</span>{player.number ?? '—'}<span className={`absolute -right-3 -top-2 flex h-5 min-w-5 items-center justify-center rounded-full border border-white/60 px-1 text-[9px] font-black shadow ${ratingClass(player.rating)}`}>{player.rating.toFixed(1)}</span></div><span className="mt-1 block max-w-24 truncate rounded bg-black/60 px-1 text-[10px] font-bold text-white">{player.name}</span></div>)}</div><div className="mt-2 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-zinc-500"><span>{sideKey === 'home' ? 'Хозяева' : 'Гости'} · {side.lineup.length} игроков</span><span className="text-emerald-400">{side.lineup.length ? 'Схема поля' : 'Нет состава'}</span></div><div className="mt-3 space-y-1">{side.bench.map((player) => <div key={player.id} className="flex items-center justify-between rounded-md border border-zinc-800 bg-black/30 px-2.5 py-1.5 text-xs"><span className="text-zinc-300">{player.number ? `${player.number} · ` : ''}{player.name}</span><span className={`rounded-full px-1.5 py-0.5 font-bold ${ratingClass(player.rating)}`}>{player.rating.toFixed(1)}</span></div>)}</div></div>;
}
function EventRow({ event, homeName }: { event: MatchEvent; homeName: string }) { const label = event.type === 'goal' ? `${event.player}${event.assist ? ` · пас: ${event.assist}` : ''}${event.penalty ? ' · пенальти' : ''}${event.ownGoal ? ' · автогол' : ''}` : event.type === 'card' ? `${event.card === 'red' ? 'Красная' : 'Жёлтая'} карточка · ${event.player}` : `Замена · ${event.playerOut} → ${event.playerIn}`; return <div className="flex items-start gap-3 rounded-xl border border-zinc-800 bg-black/30 p-3"><span className="w-8 shrink-0 text-sm font-black text-emerald-400">{event.minute}'</span><span className="text-xs leading-relaxed text-zinc-300">{label}<small className="mt-1 block text-zinc-600">{event.side === 'home' ? homeName : 'Гости'}</small></span><span className="ml-auto">{event.type === 'goal' ? <Goal className="h-4 w-4 text-emerald-400" /> : event.type === 'card' ? <span className={`block h-4 w-3 rounded-sm ${event.card === 'red' ? 'bg-red-500' : 'bg-yellow-400'}`} /> : <RefreshCw className="h-4 w-4 text-blue-400" />}</span></div>; }
