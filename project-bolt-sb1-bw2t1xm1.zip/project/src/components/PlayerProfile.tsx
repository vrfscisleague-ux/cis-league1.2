import { useEffect } from 'react';
import {
  X, ArrowLeft, Crown, Star, Award, Zap, Target, Trophy, Goal, Hand, Shield, Calendar,
  Medal, UserCheck, TrendingUp,
} from 'lucide-react';
import { seasonAwards, topScorersS1, topScorersS2, ballonDorS1, hallOfFame } from '@/data/mockData';
import { useData, type EditableLegend } from '@/context/DataContext';

interface PlayerProfileProps {
  legend: EditableLegend;
  onClose: () => void;
}

const awardIconLabel: Record<string, string> = {
  ballondor: 'Ballon d\'Or',
  boot: 'Golden Boot',
  playmaker: 'Playmaker',
  defender: 'Best Defender',
  glove: 'Golden Glove',
  boy: 'Golden Boy',
  manager: 'Best Manager',
};

interface CareerStop {
  club: string;
  logo: string;
  period: string;
  role: string;
  note: string;
  current?: boolean;
}

const rinoCareer: CareerStop[] = [
  {
    club: 'Шахтар Донецк',
    logo: '/shakhtar.webp',
    period: 'Ноябрь 2024',
    role: 'Начало карьеры',
    note: 'Дебют в VRFS и первые шаги в топовом клубе СНГ.',
  },
  {
    club: 'Performance FC',
    logo: '/image copy 3.png',
    period: '2025 — основатель',
    role: 'Основатель · Капитан · Звёздный страйкер',
    note: 'Создал легендарный клуб, выиграл CIS Cup S2 и S3, оформил хет-трик в гранд-финале.',
  },
  {
    club: 'Latvia FC',
    logo: '/image copy 2.png',
    period: '2026 — наст. время',
    role: 'Игрок основы',
    note: 'Текущий клуб. Элитный топ-клуб СНГ, обладатель UCA League.',
    current: true,
  },
];

function aggregateRiNOStats() {
  let goals = 0;
  let assists = 0;
  let awards = 0;

  topScorersS1.forEach((s) => {
    if (s.nickname === 'RiNO') goals += s.goals;
  });
  topScorersS2.forEach((s) => {
    if (s.nickname === 'RiNO') goals += s.goals;
  });
  ballonDorS1.forEach((b) => {
    if (b.nickname === 'RINO PAPA' || b.nickname === 'RiNO') {
      goals += b.goals;
      assists += b.assists;
    }
  });

  seasonAwards.forEach((season) => {
    season.awards.forEach((award) => {
      if (award.winner === 'RiNO') awards += 1;
    });
  });

  const mvpSeasons = hallOfFame.filter((h) => h.mvp === 'RiNO').length;
  const matches = 14;
  const drySheets = 0;
  const goalPlusPass = goals + assists;

  return { goals, assists, awards, matches, drySheets, goalPlusPass, mvpSeasons };
}

export default function PlayerProfile({ legend, onClose }: PlayerProfileProps) {
  const { clubs } = useData();
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handler);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  const isRiNO = legend.nickname === 'RiNO';
  const baseStats = isRiNO ? aggregateRiNOStats() : { goals: 0, assists: 0, awards: 0, matches: 0, drySheets: 0, goalPlusPass: 0, mvpSeasons: 0 };
  const stats = {
    ...baseStats,
    goals: legend.goals ?? baseStats.goals,
    assists: legend.assists ?? baseStats.assists,
    matches: legend.matches ?? baseStats.matches,
    goalPlusPass: (legend.goals ?? baseStats.goals) + (legend.assists ?? baseStats.assists),
  };
  const rinoAwards = isRiNO
    ? seasonAwards.flatMap((season) =>
        season.awards
          .filter((a) => a.winner === 'RiNO')
          .map((a) => ({ title: a.title, season: season.season, year: season.year, icon: a.icon, description: a.description }))
      )
    : [];
  const career = isRiNO ? rinoCareer : [];
  const championClubs = isRiNO ? clubs.filter((c) => c.roster.includes('RiNO') || c.keyPersons.some((p) => p.name === 'RiNO')) : [];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div
        className="mx-auto my-0 min-h-screen w-full max-w-3xl bg-gradient-to-b from-zinc-950 to-black shadow-2xl ring-1 ring-rose-900/30 md:my-6 md:min-h-0 md:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner */}
        <div className="relative h-40 w-full overflow-hidden md:rounded-t-2xl">
          <div className="absolute inset-0 bg-gradient-to-br from-rose-900 via-rose-950 to-black" />
          <div className="absolute inset-0 opacity-30 [background-image:radial-gradient(circle_at_20%_30%,rgba(244,63,94,0.4),transparent_50%),radial-gradient(circle_at_80%_70%,rgba(244,63,94,0.3),transparent_50%)]" />
          <button
            onClick={onClose}
            className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-black/40 text-white ring-1 ring-white/20 transition hover:bg-black/60 hover:ring-white/40"
            aria-label="Закрыть"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="absolute bottom-4 left-6 flex items-end gap-4">
            <div className="flex h-24 w-24 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-700 to-rose-950 text-2xl font-extrabold text-white ring-2 ring-rose-500/50 shadow-xl">
              {legend.nickname.slice(0, 2).toUpperCase()}
            </div>
            <div className="pb-1">
              <h2 className="text-2xl font-extrabold text-white drop-shadow md:text-3xl">{legend.nickname}</h2>
              <span className="mt-1 inline-flex items-center gap-1.5 rounded-md bg-rose-950/70 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-rose-300 ring-1 ring-rose-700/50">
                <Star className="h-3 w-3" /> {legend.badge}
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-7 p-6 md:p-8">
          {/* Role + back */}
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-sm font-semibold text-zinc-400 transition hover:text-rose-400"
          >
            <ArrowLeft className="h-4 w-4" /> Назад к почетным игрокам
          </button>
          <p className="-mt-2 text-sm font-semibold text-rose-400">{legend.role}</p>

          {/* Current Club */}
          {(() => {
            const clubId = legend.currentClubId ?? (isRiNO ? 'latvia' : null);
            const currentClub = clubId ? clubs.find((c) => c.id === clubId) : null;
            if (!currentClub) return null;
            const clubRoleText = legend.clubRole ?? 'Игрок';
            return (
              <div>
                <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
                  <Shield className="h-4 w-4 text-rose-500" /> Текущий клуб
                </h3>
                <div className="flex items-center gap-4 rounded-xl border border-rose-900/40 bg-rose-950/20 p-4">
                  <img src={currentClub.logo} alt={currentClub.name} className="h-14 w-14 rounded-xl object-cover ring-1 ring-zinc-700" />
                  <div className="min-w-0 flex-1">
                    <h4 className="text-lg font-bold text-white">{currentClub.name}</h4>
                    <p className="text-sm text-zinc-400">{clubRoleText}</p>
                    <p className="mt-0.5 text-xs text-zinc-500">Основан: {currentClub.founded} · {currentClub.country}</p>
                  </div>
                  {currentClub.status === 'active' && (
                    <span className="rounded bg-emerald-950/60 px-2 py-1 text-[10px] font-bold uppercase text-emerald-400 ring-1 ring-emerald-700/40">
                      Активен
                    </span>
                  )}
                </div>
              </div>
            );
          })()}

          {/* Full Stats */}
          <div>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
              <TrendingUp className="h-4 w-4 text-rose-500" /> Полная статистика
            </h3>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              <StatCard icon={<Goal className="h-4 w-4" />} label="Голы" value={stats.goals} />
              <StatCard icon={<Hand className="h-4 w-4" />} label="Ассисты" value={stats.assists} />
              <StatCard icon={<Zap className="h-4 w-4" />} label="Гол+Пас" value={stats.goalPlusPass} />
              <StatCard icon={<Calendar className="h-4 w-4" />} label="Матчи" value={stats.matches} />
              <StatCard icon={<Shield className="h-4 w-4" />} label="Сухие матчи" value={stats.drySheets} />
              <StatCard icon={<Trophy className="h-4 w-4" />} label="Награды" value={stats.awards} />
              <StatCard icon={<Medal className="h-4 w-4" />} label="MVP сезонов" value={stats.mvpSeasons} />
              <StatCard icon={<UserCheck className="h-4 w-4" />} label="Титулы (клубы)" value={championClubs.length} />
            </div>
          </div>

          {/* Individual Awards */}
          {rinoAwards.length > 0 && (
            <div>
              <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
                <Trophy className="h-4 w-4 text-amber-400" /> Индивидуальные награды
              </h3>
              <div className="space-y-2">
                {rinoAwards.map((a, i) => (
                  <div key={i} className="flex items-center gap-3 rounded-xl border border-amber-800/40 bg-amber-950/20 p-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-950/60 ring-1 ring-amber-700/40">
                      <Trophy className="h-5 w-5 text-amber-400" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-amber-200">{awardIconLabel[a.icon ?? ''] ?? a.title}</p>
                      <p className="truncate text-xs text-zinc-500">{a.description}</p>
                    </div>
                    <span className="shrink-0 rounded-md bg-amber-900/40 px-2 py-1 text-[11px] font-bold text-amber-300">
                      {a.season} · {a.year}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Career Timeline */}
          {career.length > 0 && (
            <div>
              <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
                <Crown className="h-4 w-4 text-rose-500" /> Карьера и клубы
              </h3>
              <div className="relative space-y-4 pl-6">
                <div className="absolute left-2.5 top-2 bottom-2 w-px bg-gradient-to-b from-rose-700/60 via-rose-800/40 to-transparent" />
                {career.map((stop, i) => (
                  <div key={i} className="relative">
                    <div className="absolute -left-[18px] top-1.5 h-3 w-3 rounded-full bg-rose-600 ring-2 ring-black ring-offset-1 ring-offset-rose-600" />
                    <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4">
                      <div className="flex items-center gap-3">
                        <img src={stop.logo} alt={stop.club} className="h-10 w-10 rounded-lg object-cover ring-1 ring-zinc-700" />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="truncate text-sm font-bold text-white">{stop.club}</h4>
                            {stop.current && (
                              <span className="rounded bg-emerald-950/60 px-1.5 py-0.5 text-[10px] font-bold uppercase text-emerald-400 ring-1 ring-emerald-700/40">
                                Сейчас
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-rose-400">{stop.role}</p>
                        </div>
                        <span className="shrink-0 text-[11px] font-semibold text-zinc-500">{stop.period}</span>
                      </div>
                      <p className="mt-2 text-xs leading-relaxed text-zinc-400">{stop.note}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Strengths */}
          <div>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
              <Zap className="h-4 w-4 text-rose-500" /> Лучшие качества
            </h3>
            <div className="flex flex-wrap gap-2">
              {legend.strengths.map((s) => (
                <span key={s} className="rounded-lg border border-zinc-800 bg-zinc-900/60 px-3 py-1.5 text-xs font-semibold text-zinc-300 transition hover:border-rose-700/50 hover:text-white">
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Biography / Achievements */}
          <div>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-zinc-500">
              <Award className="h-4 w-4 text-rose-500" /> Биография и достижения
            </h3>
            <ul className="space-y-2">
              {legend.achievements.map((a, i) => (
                <li key={i} className="flex gap-2.5 text-sm text-zinc-400">
                  <Target className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
                  <span className="leading-relaxed">{a}</span>
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={onClose}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900/60 py-3 text-sm font-bold text-zinc-300 transition hover:border-rose-700/50 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" /> Назад к почетным игрокам
          </button>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-xl border border-rose-900/40 bg-rose-950/20 p-3 text-center">
      <div className="flex items-center justify-center gap-1 text-[10px] font-bold uppercase tracking-wider text-rose-400">
        {icon} {label}
      </div>
      <div className="mt-1 text-2xl font-extrabold text-white">{value}</div>
    </div>
  );
}
