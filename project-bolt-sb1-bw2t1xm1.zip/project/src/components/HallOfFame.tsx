import { Trophy, Medal, Crown, Award, Shield, Star, Flame } from 'lucide-react';
import { hallOfFame, seasonAwards, ballonDorS1, topScorersS1, topScorersS2, type Award as AwardType, type TopScorer } from '@/data/mockData';

const medalStyles: Record<'gold' | 'silver' | 'bronze', { ring: string; bg: string; text: string; label: string }> = {
  gold: { ring: 'ring-amber-400/60', bg: 'from-amber-500/20 to-amber-900/10', text: 'text-amber-300', label: 'Золото' },
  silver: { ring: 'ring-zinc-300/40', bg: 'from-zinc-300/15 to-zinc-600/10', text: 'text-zinc-200', label: 'Серебро' },
  bronze: { ring: 'ring-amber-700/50', bg: 'from-amber-700/15 to-amber-950/10', text: 'text-amber-500', label: 'Бронза' },
};

const awardIcons: Record<NonNullable<AwardType['icon']>, typeof Trophy> = {
  ballondor: Trophy,
  boot: Award,
  playmaker: Star,
  defender: Shield,
  glove: Shield,
  boy: Medal,
  manager: Crown,
};

export default function HallOfFame() {
  return (
    <div className="space-y-12">
      <div className="text-center">
        <h2 className="text-3xl font-extrabold text-white md:text-4xl">Зал Славы</h2>
        <p className="mt-2 text-zinc-500">Чемпионы и лауреаты прошлых сезонов CIS League</p>
      </div>

      {/* Champions timeline */}
      <section>
        <h3 className="mb-5 flex items-center gap-2 text-xl font-bold text-white">
          <Crown className="h-5 w-5 text-rose-500" /> Чемпионы сезонов
        </h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {hallOfFame.map((c, idx) => (
            <div
              key={c.id}
              className="group relative overflow-hidden rounded-xl border border-zinc-800 bg-gradient-to-br from-zinc-950 to-black p-6 transition hover:border-rose-700/70"
            >
              <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-rose-800/10 blur-2xl transition group-hover:bg-rose-700/20" />
              <div className="flex items-center justify-between">
                <span className="rounded-md bg-rose-950/60 px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-rose-300 ring-1 ring-rose-700/40">
                  {c.season}
                </span>
                {idx === 0 && <Trophy className="h-5 w-5 text-zinc-600" />}
              </div>
              <div className="mt-4 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-rose-600 to-rose-950 ring-1 ring-rose-500/40">
                  <Trophy className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-zinc-500">Чемпион</p>
                  <p className="text-lg font-extrabold text-white">{c.champion}</p>
                </div>
              </div>
              <div className="mt-4 space-y-1.5 text-sm">
                <p className="flex justify-between"><span className="text-zinc-500">Финалист</span><span className="font-semibold text-zinc-200">{c.runnerUp}</span></p>
                <p className="flex justify-between"><span className="text-zinc-500">MVP</span><span className="font-semibold text-rose-400">{c.mvp}</span></p>
                <p className="flex justify-between"><span className="text-zinc-500">Дата</span><span className="font-semibold text-zinc-300">{c.date}</span></p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Top Scorers — Black & Neon Red Cyber Theme */}
      <TopScorersBlock seasonLabel="S1 Top Scorers" subtitle="1-й сезон · 2025" scorers={topScorersS1} />
      <TopScorersBlock seasonLabel="S2 Top Scorers" subtitle="2-й сезон · 2025" scorers={topScorersS2} />

      {/* Ballon d'Or Top-3 — Gold & White Royal Theme */}
      <section className="relative overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-950/40 to-black p-6 md:p-8">
        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-amber-600/10 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-amber-700 ring-1 ring-amber-300/50">
              <Trophy className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-amber-300 md:text-2xl">Топ-3 «Золотого мяча» · S1</h3>
              <p className="text-sm text-amber-100/70">Ballon d'Or Top 3 — 1-й сезон 2025</p>
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {ballonDorS1.map((entry) => {
              const style = medalStyles[entry.medal];
              return (
                <div
                  key={entry.rank}
                  className={`relative overflow-hidden rounded-xl border border-amber-500/30 bg-gradient-to-br ${style.bg} p-5 ring-1 ${style.ring}`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${style.bg} text-sm font-extrabold ${style.text} ring-1 ${style.ring}`}>
                      {entry.rank}
                    </span>
                    <span className={`text-[11px] font-bold uppercase tracking-wider ${style.text}`}>{style.label}</span>
                  </div>
                  <p className="mt-4 text-lg font-extrabold text-white">{entry.nickname}</p>
                  <p className="text-xs text-amber-100/70">{entry.alias} · {entry.position}</p>
                  <div className="mt-4 space-y-1 text-sm">
                    <p className="flex justify-between"><span className="text-amber-100/60">POTM</span><span className="font-bold text-amber-300">{entry.potms}</span></p>
                    <p className="flex justify-between"><span className="text-amber-100/60">Голы</span><span className="font-bold text-white">{entry.goals}</span></p>
                    <p className="flex justify-between"><span className="text-amber-100/60">Ассисты</span><span className="font-bold text-white">{entry.assists}</span></p>
                  </div>
                  <p className="mt-3 text-xs text-amber-200/80">{entry.note}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Official Season Awards — Gold & White Royal Theme */}
      {seasonAwards.map((group) => (
        <section key={group.season}>
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 ring-1 ring-amber-300/50">
              <Award className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-amber-300">{group.season} Awards</h3>
              <p className="text-xs text-amber-100/60">Индивидуальные награды · {group.year}</p>
            </div>
            <div className="ml-2 h-px flex-1 bg-gradient-to-r from-amber-500/40 to-transparent" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {group.awards.map((a) => {
              const Icon = a.icon ? awardIcons[a.icon] : Medal;
              return (
                <div
                  key={a.id}
                  className="group relative overflow-hidden rounded-xl border border-amber-500/30 bg-gradient-to-br from-amber-950/40 to-black p-5 transition hover:border-amber-400/60 hover:from-amber-900/30"
                >
                  <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-amber-500/10 blur-2xl transition group-hover:bg-amber-400/20" />
                  <div className="flex items-start gap-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-amber-700 ring-1 ring-amber-300/50">
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-white">{a.title}</p>
                      <p className="mt-0.5 text-sm font-semibold text-amber-300">@{a.winner}</p>
                      {a.alias && <p className="text-xs text-amber-100/60">{a.alias}</p>}
                      <p className="mt-1 text-xs text-amber-100/70">{a.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}

function TopScorersBlock({ seasonLabel, subtitle, scorers }: { seasonLabel: string; subtitle: string; scorers: TopScorer[] }) {
  const podium = scorers.slice(0, 3);
  const rest = scorers.slice(3);
  return (
    <section className="relative overflow-hidden rounded-2xl border border-red-600/50 bg-gradient-to-br from-black to-zinc-950 p-6 shadow-lg shadow-red-900/30 md:p-8">
      <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-red-600/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-red-500/10 blur-3xl" />
      <div className="relative">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-800 ring-1 ring-red-400/50 shadow-lg shadow-red-900/40">
            <Flame className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-red-500 md:text-2xl">{seasonLabel}</h3>
            <p className="text-sm text-zinc-400">{subtitle}</p>
          </div>
        </div>

        {/* Podium — Top 3 neon-red cards */}
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {podium.map((s) => (
            <div
              key={s.rank}
              className="group relative overflow-hidden rounded-xl border border-red-600/50 bg-gradient-to-br from-red-950/40 to-black p-5 ring-1 ring-red-500/30 transition hover:border-red-500 hover:shadow-lg hover:shadow-red-900/40"
            >
              <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-red-500/15 blur-2xl transition group-hover:bg-red-500/25" />
              <div className="flex items-center justify-between">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-red-500 to-red-800 text-base font-extrabold text-white ring-1 ring-red-400/50 shadow shadow-red-900/40">
                  {s.rank}
                </span>
                <span className="rounded-md bg-red-950/60 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-red-400 ring-1 ring-red-600/40">
                  Top {s.rank}
                </span>
              </div>
              <p className="mt-4 text-lg font-extrabold text-white">@{s.nickname}</p>
              <div className="mt-3 flex items-end gap-2">
                <span className="text-3xl font-extrabold text-red-500">{s.goals}</span>
                <span className="mb-1 text-xs uppercase tracking-wider text-zinc-500">Goals</span>
              </div>
            </div>
          ))}
        </div>

        {/* Remaining ranks — compact red-neon table */}
        {rest.length > 0 && (
          <div className="mt-4 overflow-hidden rounded-xl border border-red-600/40 bg-black/60">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-red-600/40 bg-red-950/30 text-left text-xs uppercase tracking-wider text-red-400">
                  <th className="px-4 py-2.5 font-bold">#</th>
                  <th className="px-4 py-2.5 font-bold">Игрок</th>
                  <th className="px-4 py-2.5 text-right font-bold">Goals</th>
                </tr>
              </thead>
              <tbody>
                {rest.map((s) => (
                  <tr
                    key={s.rank}
                    className="border-b border-red-950/40 transition hover:bg-red-950/20"
                  >
                    <td className="px-4 py-2.5 font-bold text-red-500">{s.rank}</td>
                    <td className="px-4 py-2.5 font-semibold text-white">@{s.nickname}</td>
                    <td className="px-4 py-2.5 text-right font-extrabold text-red-500">{s.goals}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
