import { Archive, Calendar, CheckCircle2, ChevronRight, MapPin, Trophy, Users } from 'lucide-react';
import { clubs, type Club } from '@/data/mockData';

interface ClubsProps {
  onSelectClub: (clubId: string) => void;
}

function StatusBadge({ status }: { status: Club['status'] }) {
  if (status === 'active') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md bg-emerald-950/60 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-emerald-300 ring-1 ring-emerald-600/50">
        <CheckCircle2 className="h-3 w-3" /> Действующий клуб
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 rounded-md bg-zinc-900/80 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-zinc-400 ring-1 ring-zinc-700/60">
      <Archive className="h-3 w-3" /> Архивный клуб
    </span>
  );
}

function ClubCard({ club, onSelect }: { club: Club; onSelect: () => void }) {
  const archived = club.status === 'inactive';

  return (
    <button
      type="button"
      onClick={onSelect}
      className={`group relative w-full cursor-pointer overflow-hidden rounded-2xl border p-6 text-left transition-all hover:scale-[1.02] hover:border-red-500/80 ${
        archived
          ? 'border-zinc-800 bg-gradient-to-br from-zinc-950 to-black opacity-80 hover:opacity-100'
          : 'border-zinc-800 bg-gradient-to-br from-zinc-950 to-black'
      }`}
      aria-label={`Открыть страницу клуба ${club.name}`}
    >
      <div className={`pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gradient-to-br ${club.accent} opacity-10 blur-2xl transition group-hover:opacity-20`} />

      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-neutral-800 bg-neutral-900/80 p-1.5 object-contain">
            <img src={club.logo} alt={`${club.name} — логотип`} className="w-full h-full object-contain mix-blend-screen bg-transparent" />
          </div>
          <div className="min-w-0">
            <h3 className="truncate text-lg font-extrabold text-white">{club.name}</h3>
            <p className="flex items-center gap-1 text-xs text-zinc-500"><MapPin className="h-3 w-3" /> {club.country}</p>
          </div>
        </div>
        <ChevronRight className="h-5 w-5 shrink-0 text-zinc-600 transition group-hover:translate-x-1 group-hover:text-red-400" />
      </div>

      <div className="mt-4"><StatusBadge status={club.status} /></div>
      <p className="mt-4 flex items-start gap-2 text-sm text-red-400"><Trophy className="mt-0.5 h-4 w-4 shrink-0" /> {club.achievement}</p>
      <div className="mt-4 flex items-center gap-2 text-xs text-zinc-500"><Calendar className="h-3.5 w-3.5" /> Основан в {club.founded}</div>

      {club.roster.length > 0 && (
        <div className="mt-4">
          <p className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-zinc-500"><Users className="h-3.5 w-3.5" /> Состав ({club.roster.length})</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {club.roster.map((player) => <span key={player} className="rounded-md border border-zinc-800 bg-zinc-900/60 px-2 py-1 text-xs font-semibold text-zinc-300">{player}</span>)}
          </div>
        </div>
      )}
    </button>
  );
}

export default function Clubs({ onSelectClub }: ClubsProps) {
  const activeClubs = clubs.filter((club) => club.status === 'active');
  const archivedClubs = clubs.filter((club) => club.status === 'inactive');

  const renderClubGrid = (items: Club[]) => (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((club) => <ClubCard key={club.id} club={club} onSelect={() => onSelectClub(club.id)} />)}
    </div>
  );

  return (
    <div className="space-y-10">
      <div className="text-center">
        <h2 className="text-3xl font-extrabold text-white md:text-4xl">Клубы СНГ</h2>
        <p className="mt-2 text-zinc-500">Откройте клуб, чтобы посмотреть его историю, достижения и ключевых персон</p>
      </div>

      <section>
        <div className="mb-4 flex items-center gap-3"><span className="inline-flex items-center gap-1.5 rounded-md bg-emerald-950/60 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-emerald-300 ring-1 ring-emerald-600/50"><CheckCircle2 className="h-4 w-4" /> Действующие клубы</span><div className="h-px flex-1 bg-gradient-to-r from-emerald-700/40 to-transparent" /></div>
        {renderClubGrid(activeClubs)}
      </section>

      <section>
        <div className="mb-4 flex items-center gap-3"><span className="inline-flex items-center gap-1.5 rounded-md bg-zinc-900/80 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-zinc-400 ring-1 ring-zinc-700/60"><Archive className="h-4 w-4" /> Архивные клубы</span><div className="h-px flex-1 bg-gradient-to-r from-zinc-700/40 to-transparent" /></div>
        {renderClubGrid(archivedClubs)}
      </section>
    </div>
  );
}
